package com.abismo.oceanico.world;

import com.abismo.oceanico.ModRegistry;
import com.abismo.oceanico.block.WaterBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import java.util.*;

/**
 * Arbol submarino propio. "raiz_abisal": tronco con raices y copa de hojas. "hongo": tronco con gran sombrero
 * (el sombrero son bloques de hojas: decaen, sueltan brotes y tienen distancia como cualquier arbol).
 * Se usa tanto en la generacion natural como al crecer el brote.
 */
public class AbyssTreeFeature extends Feature<NoneFeatureConfiguration> {
    private final String base;
    private final boolean mushroom;

    public AbyssTreeFeature(String base) {
        super(NoneFeatureConfiguration.CODEC);
        this.base = base;
        this.mushroom = base.equals("hongo");
    }

    private static boolean replaceable(BlockState s) {
        return s.isAir() || s.is(net.minecraft.world.level.block.Blocks.WATER) || s.is(BlockTags.LEAVES)
                || s.is(BlockTags.SAPLINGS) || s.getBlock() instanceof WaterBlock;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        BlockPos o = ctx.origin();
        RandomSource r = ctx.random();
        Block logB = ModRegistry.BLOCKS.get(base + "_log"), leafB = ModRegistry.BLOCKS.get(base + "_leaves");
        int h = mushroom ? 5 + r.nextInt(5) : 7 + r.nextInt(5);
        if (!lv.getBlockState(o.below()).canOcclude()) return false;
        for (int y = 0; y <= h + 4; y++) if (!replaceable(lv.getBlockState(o.above(y)))) return false;

        Map<BlockPos, BlockState> logs = new LinkedHashMap<>();
        Set<BlockPos> leaves = new LinkedHashSet<>();
        BlockState vertical = logB.defaultBlockState();
        for (int y = 0; y < h; y++) logs.put(o.above(y), vertical);

        if (!mushroom) {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                int len = 1 + r.nextInt(2);
                for (int i = 1; i <= len; i++) {
                    BlockPos p = o.relative(d, i);
                    if (replaceable(lv.getBlockState(p))) logs.put(p, vertical.setValue(RotatedPillarBlock.AXIS, d.getAxis()));
                }
            }
            BlockPos c = o.above(h - 1);
            for (int dx = -3; dx <= 3; dx++) for (int dy = -2; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++) {
                double d = (dx * dx + dz * dz) / 9.5 + (dy * dy) / 7.0;
                if (d <= 1.0 && (d < 0.75 || r.nextInt(3) != 0)) leaves.add(c.offset(dx, dy, dz));
            }
            for (int i = 0; i < 6; i++) leaves.add(c.offset(r.nextInt(5) - 2, -3 - r.nextInt(2), r.nextInt(5) - 2));
        } else {
            logs.put(o.above(h), vertical);
            for (int dy = -1; dy <= 3; dy++) {
                int rad = switch (dy) { case -1 -> 4; case 0 -> 4; case 1 -> 3; case 2 -> 2; default -> 1; };
                for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > rad + 0.4) continue;
                    if (dy == -1 && d < rad - 0.9) continue;      // borde colgante del sombrero
                    leaves.add(o.offset(dx, h + dy, dz));
                }
            }
        }
        for (BlockPos p : logs.keySet()) leaves.remove(p);

        // distancias reales a los troncos para que las hojas no decaigan al instante
        Map<BlockPos, Integer> dist = new HashMap<>();
        Deque<BlockPos> q = new ArrayDeque<>();
        for (BlockPos l : logs.keySet()) for (Direction d : Direction.values()) {
            BlockPos n = l.relative(d);
            if (leaves.contains(n) && !dist.containsKey(n)) { dist.put(n, 1); q.add(n); }
        }
        while (!q.isEmpty()) {
            BlockPos p = q.poll();
            int dd = dist.get(p);
            if (dd >= 6) continue;
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (leaves.contains(n) && !dist.containsKey(n)) { dist.put(n, dd + 1); q.add(n); }
            }
        }

        for (Map.Entry<BlockPos, BlockState> e : logs.entrySet()) set(lv, e.getKey(), e.getValue());
        for (BlockPos p : leaves) {
            if (!replaceable(lv.getBlockState(p))) continue;
            boolean water = lv.getFluidState(p).is(FluidTags.WATER);
            BlockState s = leafB.defaultBlockState().setValue(LeavesBlock.DISTANCE, dist.getOrDefault(p, 7))
                    .setValue(LeavesBlock.PERSISTENT, false).setValue(LeavesBlock.WATERLOGGED, water);
            set(lv, p, s);
        }
        return true;
    }

    private static void set(WorldGenLevel lv, BlockPos p, BlockState s) {
        if (lv.ensureCanWrite(p)) lv.setBlock(p, s, 2);
    }
}
