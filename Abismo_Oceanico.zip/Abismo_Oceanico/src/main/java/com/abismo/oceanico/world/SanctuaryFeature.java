package com.abismo.oceanico.world;

import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import static com.abismo.oceanico.world.Gen.b;

/** Santuario de las Profundidades: arena circular con altar donde se invoca al Leviatan del Abismo. */
public class SanctuaryFeature extends Feature<NoneFeatureConfiguration> {
    public SanctuaryFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        Gen g = new Gen(lv, ctx.random());
        int cx = ctx.origin().getX(), cz = ctx.origin().getZ(), y0 = ctx.origin().getY();
        BlockState brick = b("ladrillo_abisal"), tall = b("ladrillo_abisal_tallado"), pil = b("pilar_abisal"), lamp = b("lampara_marina");
        int R = 14;
        g.level(cx, cz, R + 1, y0, b("piedra_abisal"));
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d > R) continue;
            g.put(cx + x, y0 - 1, cz + z, ((int) d % 3 == 0) ? tall : brick);
            if (d > R - 1.6 && d <= R) {
                boolean gap = Math.abs(x) <= 2 || Math.abs(z) <= 2;     // 4 entradas
                for (int y = 0; y < 7; y++) if (!gap || y > 4) g.put(cx + x, y0 + y, cz + z, brick);
            }
        }
        // 8 pilares con lamparas
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            int px = cx + (int) Math.round(Math.cos(a) * 9), pz = cz + (int) Math.round(Math.sin(a) * 9);
            g.box(px, y0, pz, px, y0 + 9, pz, pil);
            g.put(px, y0 + 10, pz, lamp);
        }
        // estrado central y altar
        for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d <= 4.2) g.put(cx + x, y0, cz + z, tall);
            if (d <= 2.6) g.put(cx + x, y0 + 1, cz + z, brick);
        }
        g.put(cx, y0 + 2, cz, b("altar_abisal"));
        g.put(cx - 2, y0 + 2, cz, lamp); g.put(cx + 2, y0 + 2, cz, lamp); g.put(cx, y0 + 2, cz - 2, lamp); g.put(cx, y0 + 2, cz + 2, lamp);
        // cristales y camara del tesoro oculta tras el muro norte
        for (int i = 0; i < 10; i++) g.box(cx + g.r.nextInt(21) - 10, y0, cz + g.r.nextInt(21) - 10, cx + g.r.nextInt(21) - 10, y0, cz + g.r.nextInt(21) - 10, g.r.nextBoolean() ? b("cristal_abisal_ore") : b("coral_luminoso_violeta"));
        g.hollow(cx - 3, y0 - 1, cz - R - 5, cx + 3, y0 + 4, cz - R + 1, tall);
        g.chest(cx - 1, y0, cz - R - 3, "sanctuary");
        g.chest(cx + 1, y0, cz - R - 3, "sanctuary");
        g.put(cx, y0 + 3, cz - R - 3, lamp);
        return true;
    }
}
