package com.abismo.oceanico.world;

import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import static com.abismo.oceanico.world.Gen.b;

/** Cementerio de barcos: casco de madera parcialmente hundido, mastil roto y cofres. */
public class ShipwreckFeature extends Feature<NoneFeatureConfiguration> {
    public ShipwreckFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        Gen g = new Gen(lv, ctx.random());
        int cx = ctx.origin().getX(), cz = ctx.origin().getZ(), y0 = ctx.origin().getY() - 2;
        BlockState plank = g.r.nextBoolean() ? Blocks.DARK_OAK_PLANKS.defaultBlockState() : Blocks.SPRUCE_PLANKS.defaultBlockState();
        BlockState log = Blocks.DARK_OAK_LOG.defaultBlockState();
        int len = 10 + g.r.nextInt(4); // semi-largo
        for (int z = -len; z <= len; z++) {
            double t = (double) z / len;
            int wdt = (int) Math.round(4 * Math.sqrt(Math.max(0, 1 - t * t * t * t)));  // proa/popa afiladas
            for (int x = -wdt; x <= wdt; x++) {
                g.put(cx + x, y0, cz + z, plank);                                   // quilla
                boolean edge = Math.abs(x) == wdt;
                for (int y = 1; y <= 4; y++) {
                    if (edge && g.r.nextInt(7) != 0) g.put(cx + x, y0 + y, cz + z, (z % 4 == 0) ? log : plank);
                    else if (!edge) g.put(cx + x, y0 + y, cz + z, Gen.WATER);
                }
                if (y0 + 3 > 0 && !edge && g.r.nextInt(5) == 0) g.put(cx + x, y0 + 3, cz + z, plank); // cubierta rota
            }
        }
        // mastil roto
        g.box(cx, y0 + 1, cz + 2, cx, y0 + 5 + g.r.nextInt(6), cz + 2, Blocks.SPRUCE_FENCE.defaultBlockState());
        // camarote y cofres
        g.box(cx - 2, y0 + 1, cz - len + 2, cx + 2, y0 + 4, cz - len + 6, plank);
        g.box(cx - 1, y0 + 2, cz - len + 3, cx + 1, y0 + 3, cz - len + 5, Gen.WATER);
        g.chest(cx, y0 + 2, cz - len + 4, "wreck");
        g.chest(cx + 1, y0 + 1, cz + len - 3, "wreck");
        g.put(cx - 1, y0 + 3, cz - len + 4, b("lampara_marina"));
        // restos: anclas de piedra y coral
        for (int i = 0; i < 4; i++) g.put(cx + g.r.nextInt(9) - 4, y0 + 1, cz + g.r.nextInt(2 * len) - len, Blocks.COBBLESTONE.defaultBlockState());
        return true;
    }
}
