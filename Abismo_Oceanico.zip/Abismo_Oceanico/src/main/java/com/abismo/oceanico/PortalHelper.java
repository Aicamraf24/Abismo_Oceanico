package com.abismo.oceanico;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import com.abismo.oceanico.block.PortalBlock;

import java.util.Set;

/** Construccion, activacion y viaje del portal Mundo normal <-> Abismo Oceanico. */
public final class PortalHelper {
    private PortalHelper() {}

    private static int dx(Direction.Axis a) { return a == Direction.Axis.X ? 1 : 0; }
    private static int dz(Direction.Axis a) { return a == Direction.Axis.Z ? 1 : 0; }

    private static boolean fluidOrAir(BlockState s) { return s.isAir() || s.getFluidState().is(FluidTags.WATER); }

    /** o = esquina inferior del interior (2x3). */
    private static boolean valid(Level l, BlockPos o, Direction.Axis a, Block frame, Block portal) {
        for (int i = -1; i <= 2; i++) {
            for (int j = -1; j <= 3; j++) {
                BlockPos p = o.offset(dx(a) * i, j, dz(a) * i);
                BlockState s = l.getBlockState(p);
                boolean edgeI = i == -1 || i == 2, edgeJ = j == -1 || j == 3;
                if (edgeI && edgeJ) continue;
                if (edgeI || edgeJ) { if (!s.is(frame)) return false; }
                else if (!(fluidOrAir(s) || s.is(portal))) return false;
            }
        }
        return true;
    }

    public static boolean activate(Level l, BlockPos clicked) {
        Block frame = ModRegistry.BLOCKS.get("marco_abisal"), portal = ModRegistry.BLOCKS.get("portal_abisal");
        for (Direction.Axis a : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
            for (int x = -3; x <= 3; x++) for (int y = -4; y <= 1; y++) for (int z = -3; z <= 3; z++) {
                BlockPos o = clicked.offset(x, y, z);
                if (valid(l, o, a, frame, portal)) { fill(l, o, a, portal); return true; }
            }
        }
        return false;
    }

    private static void fill(Level l, BlockPos o, Direction.Axis a, Block portal) {
        BlockState st = portal.defaultBlockState().setValue(PortalBlock.AXIS, a);
        for (int i = 0; i <= 1; i++) for (int j = 0; j <= 2; j++) l.setBlock(o.offset(dx(a) * i, j, dz(a) * i), st, 3);
    }

    /** Construye marco + portal + plataforma en o (eje X). */
    private static void build(ServerLevel l, BlockPos o, boolean abyss) {
        Block frame = ModRegistry.BLOCKS.get("marco_abisal"), portal = ModRegistry.BLOCKS.get("portal_abisal"), brick = ModRegistry.BLOCKS.get("ladrillo_abisal");
        BlockState clear = abyss ? Blocks.WATER.defaultBlockState() : Blocks.AIR.defaultBlockState();
        for (int x = -2; x <= 3; x++) for (int y = -1; y <= 4; y++) for (int z = -2; z <= 3; z++) {
            BlockPos p = o.offset(x, y, z);
            if (y < -1) continue;
            if (!l.getBlockState(p).isAir() && !l.getBlockState(p).getFluidState().is(FluidTags.WATER) || y >= 0) l.setBlock(p, clear, 2);
        }
        for (int x = -2; x <= 3; x++) for (int z = -2; z <= 3; z++) l.setBlock(o.offset(x, -2, z), brick.defaultBlockState(), 2);
        for (int i = -1; i <= 2; i++) for (int j = -1; j <= 3; j++) {
            boolean edgeI = i == -1 || i == 2, edgeJ = j == -1 || j == 3;
            if (edgeI && edgeJ) continue;
            BlockPos p = o.offset(i, j, 0);
            l.setBlock(p, (edgeI || edgeJ) ? frame.defaultBlockState() : portal.defaultBlockState().setValue(PortalBlock.AXIS, Direction.Axis.X), 3);
        }
    }

    private static BlockPos findPortal(ServerLevel l, BlockPos c) {
        Block portal = ModRegistry.BLOCKS.get("portal_abisal");
        for (int x = -8; x <= 8; x++) for (int z = -8; z <= 8; z++) for (int y = -8; y <= 8; y++) {
            BlockPos p = c.offset(x, y, z);
            if (l.getBlockState(p).is(portal)) {
                BlockPos q = p;
                while (l.getBlockState(q.below()).is(portal)) q = q.below();
                return q;
            }
        }
        return null;
    }

    public static void travel(ServerPlayer player) {
        MinecraftServer server = player.level().getServer();
        boolean toAbyss = player.level().dimension() != ModRegistry.ABYSS;
        ServerLevel target = toAbyss ? server.getLevel(ModRegistry.ABYSS) : server.overworld();
        if (target == null) return;
        int x = player.blockPosition().getX(), z = player.blockPosition().getZ();
        target.getChunk(x >> 4, z >> 4);
        int y = toAbyss ? target.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z) + 2
                : target.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) + 1;
        BlockPos guess = new BlockPos(x, y, z);
        BlockPos found = findPortal(target, guess);
        if (found == null) { found = guess; build(target, found, toAbyss); }
        // el portal se construye sobre el eje X: salimos por el lado +z
        double tx = found.getX() + 1.0, ty = found.getY(), tz = found.getZ() + 2.0;
        player.teleportTo(target, tx, ty, tz, Set.of(), player.getYRot(), player.getXRot(), true);
        Survival.setPortalCooldown(player);
    }
}
