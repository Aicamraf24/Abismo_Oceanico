package com.abismo.oceanico.entity;

import com.abismo.oceanico.Json;
import com.abismo.oceanico.ModRegistry;
import com.google.gson.JsonObject;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Leviatan del Abismo: jefe de 3 fases con barra de jefe, mordidas, tentaculos, ondas de presion,
 * remolinos e invocacion de criaturas. No se reproduce (no extiende Animal).
 */
public class LeviathanEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            java.util.UUID.randomUUID(), Component.translatable("entity.abismo_oceanico.leviatan"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int phase = 1;
    private int attackCd = 100;
    private int whirl = 0;
    private final List<double[]> slams = new ArrayList<>(); // x,y,z,ticks

    public LeviathanEntity(EntityType<? extends LeviathanEntity> type, Level level) {
        super(type, level);
        this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02F, 0.1F, true);
        this.lookControl = new SmoothSwimmingLookControl(this, 10);
        this.navigation = new WaterBoundPathNavigation(this, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs(JsonObject sp) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, Json.f(sp, "hp", 700))
                .add(Attributes.MOVEMENT_SPEED, Json.f(sp, "spd", 1.0))
                .add(Attributes.ATTACK_DAMAGE, Json.f(sp, "dmg", 18))
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.ARMOR, 10.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        if (level().isClientSide()) return;
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
        goalSelector.addGoal(5, new RandomSwimmingGoal(this, 1.0, 30));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void travel(Vec3 v) {
        if (isEffectiveAi() && isInWater()) {
            moveRelative(getSpeed(), v);
            move(MoverType.SELF, getDeltaMovement());
            setDeltaMovement(getDeltaMovement().scale(0.9));
        } else {
            super.travel(v);
        }
    }

    @Override public boolean isPushedByFluid() { return false; }
    @Override public boolean canBreatheUnderwater() { return true; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override
    public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }
    @Override
    public void remove(Entity.RemovalReason reason) { super.remove(reason); bossEvent.removeAllPlayers(); }

    @Override
    protected void customServerAiStep(ServerLevel level) {
        super.customServerAiStep(level);
        bossEvent.setProgress(getHealth() / getMaxHealth());
        float ratio = getHealth() / getMaxHealth();
        int np = ratio > 0.66F ? 1 : ratio > 0.33F ? 2 : 3;
        if (np != phase) {
            phase = np;
            addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 120, 2));
            level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.5, getZ(), 6, 2.0, 1.0, 2.0, 0.0);
            summon(level, 3);
        }
        // losas de tentaculos programadas
        for (int i = slams.size() - 1; i >= 0; i--) {
            double[] s = slams.get(i);
            s[3]--;
            level.sendParticles(ParticleTypes.BUBBLE, s[0], s[1] + 0.2, s[2], 3, 0.8, 0.1, 0.8, 0.0);
            if (s[3] <= 0) {
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(s[0] - 2.2, s[1] - 3, s[2] - 2.2, s[0] + 2.2, s[1] + 5, s[2] + 2.2), this::isEnemy)) {
                    e.hurtServer(level, damageSources().mobAttack(this), 10.0F + phase * 2);
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.6, 0));
                    e.hurtMarked = true;
                }
                level.sendParticles(ParticleTypes.POOF, s[0], s[1] + 0.5, s[2], 25, 1.0, 0.4, 1.0, 0.1);
                slams.remove(i);
            }
        }
        if (whirl > 0) {
            whirl--;
            for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(22.0), this::isEnemyPlayer)) {
                Vec3 to = position().subtract(p.position()).normalize().scale(0.09);
                Vec3 swirl = new Vec3(-to.z, 0.0, to.x).scale(1.4);
                p.setDeltaMovement(p.getDeltaMovement().add(to).add(swirl));
                p.hurtMarked = true;
            }
            level.sendParticles(ParticleTypes.BUBBLE_POP, getX(), getY() + 1, getZ(), 12, 5.0, 2.0, 5.0, 0.2);
        }
        LivingEntity t = getTarget();
        if (t == null) return;
        if (--attackCd <= 0) {
            chooseAttack(level, t);
            attackCd = Math.max(40, 120 - phase * 25);
        }
    }

    private boolean isEnemyPlayer(Player p) { return !p.isCreative() && !p.isSpectator(); }
    private boolean isEnemy(LivingEntity e) {
        return e != this && !(e instanceof SeaCreature) && !(e instanceof LeviathanEntity) && !(e instanceof Player p && !isEnemyPlayer(p));
    }

    private void chooseAttack(ServerLevel level, LivingEntity t) {
        int pick = random.nextInt(phase == 1 ? 2 : phase == 2 ? 4 : 5);
        switch (pick) {
            case 0, 1 -> { // golpe de tentaculos
                int n = 2 + phase * 2;
                for (int i = 0; i < n; i++) {
                    double ox = (i == 0 ? 0 : (random.nextDouble() - 0.5) * 9.0);
                    double oz = (i == 0 ? 0 : (random.nextDouble() - 0.5) * 9.0);
                    slams.add(new double[]{t.getX() + ox, t.getY(), t.getZ() + oz, 25});
                }
            }
            case 2 -> { // onda de presion
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 1.5, getZ(), 1, 0, 0, 0, 0);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(18.0), this::isEnemy)) {
                    e.hurtServer(level, damageSources().mobAttack(this), 7.0F + phase * 2);
                    Vec3 d = e.position().subtract(position()).normalize();
                    e.setDeltaMovement(d.x * 1.6, 0.4, d.z * 1.6);
                    e.hurtMarked = true;
                    e.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 120, 0));
                }
            }
            case 3 -> whirl = 80 + phase * 20; // remolino
            default -> summon(level, 2 + phase); // invocacion
        }
    }

    private void summon(ServerLevel level, int n) {
        int existing = level.getEntitiesOfClass(SeaCreature.class, getBoundingBox().inflate(40.0)).size();
        String[] pool = {"pez_abisal_dentado", "anguila_electrica_gigante", "tiburon_abisal", "guardian_coralino"};
        for (int i = 0; i < n && existing < 8; i++, existing++) {
            EntityType<?> type = ModRegistry.ENTITIES.get(pool[random.nextInt(pool.length)]);
            Entity e = type.create(level, EntitySpawnReason.MOB_SUMMONED);
            if (e == null) continue;
            e.setPos(getX() + (random.nextDouble() - 0.5) * 12, getY() + random.nextDouble() * 3, getZ() + (random.nextDouble() - 0.5) * 12);
            if (e instanceof Mob m && getTarget() != null) m.setTarget(getTarget());
            level.addFreshEntity(e);
        }
    }

    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean r = super.doHurtTarget(level, target);
        if (r && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
        return r;
    }
}
