package com.abismo.oceanico;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/** Ayudas pequeñas para leer abismo_data.json. */
public final class Json {
    private Json() {}

    public static String s(JsonObject o, String k) { return s(o, k, ""); }
    public static String s(JsonObject o, String k, String d) { JsonElement e = o.get(k); return e == null || e.isJsonNull() ? d : e.getAsString(); }
    public static int i(JsonObject o, String k, int d) { JsonElement e = o.get(k); return e == null || e.isJsonNull() ? d : e.getAsInt(); }
    public static double f(JsonObject o, String k, double d) { JsonElement e = o.get(k); return e == null || e.isJsonNull() ? d : e.getAsDouble(); }
    public static boolean b(JsonObject o, String k) { JsonElement e = o.get(k); return e != null && !e.isJsonNull() && e.getAsBoolean(); }
}
