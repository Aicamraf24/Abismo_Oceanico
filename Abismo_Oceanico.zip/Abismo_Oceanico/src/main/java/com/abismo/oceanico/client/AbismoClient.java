package com.abismo.oceanico.client;

import com.abismo.oceanico.Data;
import com.abismo.oceanico.Ids;
import com.abismo.oceanico.Json;
import com.abismo.oceanico.ModRegistry;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import com.abismo.oceanico.AbismoOceanico;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.world.level.block.Block;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class AbismoClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Data.load();
        for (JsonElement e : Data.arr("species")) {
            JsonObject sp = e.getAsJsonObject();
            register(ModRegistry.ENTITIES.get(Json.s(sp, "id")), sp);
        }
        for (JsonElement e : Data.arr("blocks")) {
            JsonObject o = e.getAsJsonObject();
            String r = Json.s(o, "render", "solid");
            if (r.equals("solid")) continue;
            var block = ModRegistry.BLOCKS.get(Json.s(o, "id"));
            putLayer(block, r.equals("translucent") ? ChunkSectionLayer.TRANSLUCENT : ChunkSectionLayer.CUTOUT);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T extends Mob> void register(EntityType<?> type, JsonObject sp) {
        ModelLayerLocation layer = new ModelLayerLocation(Ids.id(Json.s(sp, "id")), "main");
        ModelLayerRegistry.registerModelLayer(layer, () -> SpeciesModel.layer(sp));
        EntityRenderers.register((EntityType<T>) type, ctx -> new SeaRenderer<T>(ctx, sp, layer));
    }

    /** Nombres posibles de la clase de Fabric API que asigna la capa de render (cambio de nombre entre versiones). */
    private static final String[] LAYER_MAP_CLASSES = {
            "net.fabricmc.fabric.api.client.rendering.v1.ChunkSectionLayerMap",
            "net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap",
            "net.fabricmc.fabric.api.client.renderer.v1.ChunkSectionLayerMap",
            "net.fabricmc.fabric.api.client.renderer.v1.BlockRenderLayerMap",
            "net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap"};
    private static boolean warned;

    private static void putLayer(Block block, ChunkSectionLayer layer) {
        for (String cn : LAYER_MAP_CLASSES) {
            try {
                Class<?> c = Class.forName(cn);
                for (Method m : c.getMethods()) {
                    if (m.getName().equals("putBlock") && m.getParameterCount() == 2) {
                        Object target = Modifier.isStatic(m.getModifiers()) ? null : c.getField("INSTANCE").get(null);
                        m.invoke(target, block, layer);
                        return;
                    }
                }
            } catch (ClassNotFoundException e) {
                // probar el siguiente nombre
            } catch (Throwable t) {
                AbismoOceanico.LOGGER.warn("No se pudo fijar la capa de render con {}: {}", cn, t.toString());
                return;
            }
        }
        Class<?> found = discover();
        if (found != null) {
            try {
                for (Method m : found.getMethods()) {
                    if (m.getName().equals("putBlock") && m.getParameterCount() == 2) {
                        Object target = Modifier.isStatic(m.getModifiers()) ? null : found.getField("INSTANCE").get(null);
                        m.invoke(target, block, layer);
                        return;
                    }
                }
            } catch (Throwable t) {
                AbismoOceanico.LOGGER.warn("Fallo al usar {}: {}", found.getName(), t.toString());
            }
        }
        if (!warned) {
            warned = true;
            AbismoOceanico.LOGGER.warn("No se encontró la API de capas de render de Fabric: plantas y cristales se verán opacos.");
        }
    }

    private static Class<?> discovered;
    private static boolean searched;

    /** Busca en los modulos fabric-* una clase *LayerMap con putBlock (el nombre cambio entre versiones). */
    private static Class<?> discover() {
        if (searched) return discovered;
        searched = true;
        try {
            for (ModContainer mc : FabricLoader.getInstance().getAllMods()) {
                if (!mc.getMetadata().getId().startsWith("fabric-")) continue;
                for (Path root : mc.getRootPaths()) {
                    try (Stream<Path> walk = Files.walk(root)) {
                        for (Path p : (Iterable<Path>) walk::iterator) {
                            String n = p.toString();
                            if (!n.endsWith(".class") || !n.contains("LayerMap") || n.contains("$")) continue;
                            String cn = root.relativize(p).toString().replace('/', '.').replace('\\', '.');
                            cn = cn.substring(0, cn.length() - 6);
                            try {
                                Class<?> k = Class.forName(cn);
                                for (Method m : k.getMethods()) {
                                    if (m.getName().equals("putBlock")) {
                                        discovered = k;
                                        AbismoOceanico.LOGGER.info("Clase de capas de render encontrada: {}", cn);
                                        return k;
                                    }
                                }
                            } catch (Throwable ignored) { }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            AbismoOceanico.LOGGER.warn("Busqueda de la API de capas fallida: {}", t.toString());
        }
        return discovered;
    }
}
