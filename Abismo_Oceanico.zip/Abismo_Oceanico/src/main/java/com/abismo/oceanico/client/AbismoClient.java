package com.abismo.oceanico.client;

import com.abismo.oceanico.Data;
import com.abismo.oceanico.Ids;
import com.abismo.oceanico.Json;
import com.abismo.oceanico.ModRegistry;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class AbismoClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Data.load();
        for (JsonElement e : Data.arr("species")) {
            JsonObject sp = e.getAsJsonObject();
            register(ModRegistry.ENTITIES.get(Json.s(sp, "id")), sp);
        }
        for (JsonElement e : Data.arr("blocks")) {
            JsonObject o = e.getAsJsonObject();
            String r = Json.s(o, "render", "solid");
            if (r.equals("solid")) continue;
            var block = ModRegistry.BLOCKS.get(Json.s(o, "id"));
            BlockRenderLayerMap.putBlock(block, r.equals("translucent") ? ChunkSectionLayer.TRANSLUCENT : ChunkSectionLayer.CUTOUT);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T extends Mob> void register(EntityType<?> type, JsonObject sp) {
        ModelLayerLocation layer = new ModelLayerLocation(Ids.id(Json.s(sp, "id")), "main");
        ModelLayerRegistry.registerModelLayer(layer, () -> SpeciesModel.layer(sp));
        EntityRenderers.register((EntityType<T>) type, ctx -> new SeaRenderer<T>(ctx, sp, layer));
    }
}
