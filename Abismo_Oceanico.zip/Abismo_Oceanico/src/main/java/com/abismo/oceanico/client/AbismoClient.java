package com.abismo.oceanico.client;

import com.abismo.oceanico.Data;
import com.abismo.oceanico.Ids;
import com.abismo.oceanico.Json;
import com.abismo.oceanico.ModRegistry;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import com.abismo.oceanico.AbismoOceanico;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.world.level.block.Block;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class AbismoClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Data.load();
        for (JsonElement e : Data.arr("species")) {
            JsonObject sp = e.getAsJsonObject();
            register(ModRegistry.ENTITIES.get(Json.s(sp, "id")), sp);
        }
        for (JsonElement e : Data.arr("blocks")) {
            JsonObject o = e.getAsJsonObject();
            String r = Json.s(o, "render", "solid");
            if (r.equals("solid")) continue;
            var block = ModRegistry.BLOCKS.get(Json.s(o, "id"));
            putLayer(block, r.equals("translucent") ? ChunkSectionLayer.TRANSLUCENT : ChunkSectionLayer.CUTOUT);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T extends Mob> void register(EntityType<?> type, JsonObject sp) {
        ModelLayerLocation layer = new ModelLayerLocation(Ids.id(Json.s(sp, "id")), "main");
        ModelLayerRegistry.registerModelLayer(layer, () -> SpeciesModel.layer(sp));
        EntityRenderers.register((EntityType<T>) type, ctx -> new SeaRenderer<T>(ctx, sp, layer));
    }

    /** Nombres posibles de la clase de Fabric API que asigna la capa de render (cambio de nombre entre versiones). */
    private static final String[] LAYER_MAP_CLASSES = {
            "net.fabricmc.fabric.api.client.rendering.v1.ChunkSectionLayerMap",
            "net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap",
            "net.fabricmc.fabric.api.client.renderer.v1.ChunkSectionLayerMap",
            "net.fabricmc.fabric.api.client.renderer.v1.BlockRenderLayerMap",
            "net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap"};
    private static boolean warned;

    private static void putLayer(Block block, ChunkSectionLayer layer) {
        for (String cn : LAYER_MAP_CLASSES) {
            try {
                Class<?> c = Class.forName(cn);
                for (Method m : c.getMethods()) {
                    if (m.getName().equals("putBlock") && m.getParameterCount() == 2) {
                        Object target = Modifier.isStatic(m.getModifiers()) ? null : c.getField("INSTANCE").get(null);
                        m.invoke(target, block, layer);
                        return;
                    }
                }
            } catch (ClassNotFoundException e) {
                // probar el siguiente nombre
            } catch (Throwable t) {
                AbismoOceanico.LOGGER.warn("No se pudo fijar la capa de render con {}: {}", cn, t.toString());
                return;
            }
        }
        if (!warned) {
            warned = true;
            AbismoOceanico.LOGGER.warn("No se encontró la API de capas de render de Fabric: plantas y cristales se verán opacos.");
        }
    }
}
