package com.abismo.oceanico.item;

import com.abismo.oceanico.ModRegistry;
import com.abismo.oceanico.PortalHelper;
import com.abismo.oceanico.Survival;
import com.abismo.oceanico.entity.LeviathanEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public final class SpecialItems {
    private SpecialItems() {}

    /** Capsula de oxigeno: rellena el aire y da respiracion acuatica breve. */
    public static class Oxygen extends Item {
        public Oxygen(Properties p) { super(p); }

        @Override
        public InteractionResult use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player.getAirSupply() >= player.getMaxAirSupply() && !player.isEyeInFluid(net.minecraft.tags.FluidTags.WATER)) return InteractionResult.PASS;
            if (!level.isClientSide()) {
                player.setAirSupply(player.getMaxAirSupply());
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 600, 0, true, true));
                if (!player.getAbilities().instabuild) stack.shrink(1);
            }
            return InteractionResult.SUCCESS;
        }
    }

    /** Llave de la Marea: activa un marco de portal valido. */
    public static class Key extends Item {
        public Key(Properties p) { super(p); }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            BlockPos pos = ctx.getClickedPos();
            if (!level.getBlockState(pos).is(ModRegistry.BLOCKS.get("marco_abisal"))) return InteractionResult.PASS;
            if (!level.isClientSide()) {
                if (PortalHelper.activate(level, pos)) {
                    Player pl = ctx.getPlayer();
                    if (pl == null || !pl.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
                    return InteractionResult.SUCCESS;
                }
                return InteractionResult.FAIL;
            }
            return InteractionResult.SUCCESS;
        }
    }

    /** Corazon del Abismo: invoca al Leviatan sobre el altar del Santuario. */
    public static class Heart extends Item {
        public Heart(Properties p) { super(p); }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            BlockPos pos = ctx.getClickedPos();
            if (!level.getBlockState(pos).is(ModRegistry.BLOCKS.get("altar_abisal"))) return InteractionResult.PASS;
            if (level.isClientSide()) return InteractionResult.SUCCESS;
            ServerLevel sl = (ServerLevel) level;
            if (!sl.getEntitiesOfClass(LeviathanEntity.class, new net.minecraft.world.phys.AABB(pos).inflate(90.0)).isEmpty()) {
                Survival.actionBar(ctx.getPlayer(), Component.translatable("msg.abismo_oceanico.leviathan_present"));
                return InteractionResult.FAIL;
            }
            EntityType<?> type = ModRegistry.ENTITIES.get("leviatan");
            Entity e = type.create(sl, EntitySpawnReason.MOB_SUMMONED);
            if (e == null) return InteractionResult.FAIL;
            e.setPos(pos.getX() + 0.5, pos.getY() + 4.0, pos.getZ() + 0.5);
            sl.addFreshEntity(e);
            sl.getServer().getPlayerList().broadcastSystemMessage(Component.translatable("msg.abismo_oceanico.leviathan_awakes"), false);
            Player pl = ctx.getPlayer();
            if (pl == null || !pl.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
            return InteractionResult.SUCCESS;
        }
    }
}
