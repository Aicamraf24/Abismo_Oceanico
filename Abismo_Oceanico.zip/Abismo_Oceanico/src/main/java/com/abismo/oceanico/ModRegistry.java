package com.abismo.oceanico;

import com.abismo.oceanico.block.*;
import com.abismo.oceanico.entity.LeviathanEntity;
import com.abismo.oceanico.entity.SeaCreature;
import com.abismo.oceanico.item.SpecialItems;
import com.abismo.oceanico.world.*;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.*;
import java.util.function.Function;

/** Registro data-driven: todo se describe en abismo_data.json. */
public final class ModRegistry {
    public static final Map<String, Item> ITEMS = new LinkedHashMap<>();
    public static final Map<String, Block> BLOCKS = new LinkedHashMap<>();
    public static final Map<String, EntityType<?>> ENTITIES = new LinkedHashMap<>();
    public static final Map<String, JsonObject> SPECIES = new LinkedHashMap<>();
    /** pieza de armadura -> puntos de presion */
    public static final Map<Item, Integer> PRESSURE = new HashMap<>();
    /** pieza de armadura -> id del conjunto */
    public static final Map<Item, String> ARMOR_SET = new HashMap<>();
    public static final ResourceKey<Level> ABYSS = ResourceKey.create(Registries.DIMENSION, Ids.id("abismo"));

    private static final Map<String, ArmorMaterial> ARMOR_MATS = new HashMap<>();
    private static final Map<String, ToolMaterial> TOOL_MATS = new HashMap<>();
    private static final Map<String, Integer> SET_PRESSURE = new HashMap<>();

    private ModRegistry() {}

    public static void registerAll() {
        registerMaterials();
        registerBlocks();
        registerItems();
        registerEntities();
        registerFeatures();
        registerTab();
    }

    // ------------------------------------------------------------ materiales
    private static TagKey<net.minecraft.world.item.Item> itemTag(String path) {
        return TagKey.create(Registries.ITEM, Ids.id(path));
    }

    private static void registerMaterials() {
        for (JsonElement e : Data.arr("armor_sets")) {
            JsonObject o = e.getAsJsonObject();
            String id = Json.s(o, "id");
            Map<ArmorType, Integer> def = new EnumMap<>(ArmorType.class);
            def.put(ArmorType.HELMET, Json.i(o, "head", 2));
            def.put(ArmorType.CHESTPLATE, Json.i(o, "chest", 5));
            def.put(ArmorType.LEGGINGS, Json.i(o, "legs", 4));
            def.put(ArmorType.BOOTS, Json.i(o, "feet", 2));
            ResourceKey<net.minecraft.world.item.equipment.EquipmentAsset> assetKey = ResourceKey.create(EquipmentAssets.ROOT_ID, Ids.id(id));
            ARMOR_MATS.put(id, new ArmorMaterial(Json.i(o, "durability", 20), def, Json.i(o, "enchant", 12),
                    SoundEvents.ARMOR_EQUIP_IRON, (float) Json.f(o, "toughness", 0), (float) Json.f(o, "kb", 0),
                    itemTag("repair_" + id), assetKey));
            SET_PRESSURE.put(id, Json.i(o, "pressure", 1));
        }
        for (JsonElement e : Data.arr("tool_materials")) {
            JsonObject o = e.getAsJsonObject();
            String id = Json.s(o, "id");
            TOOL_MATS.put(id, new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, Json.i(o, "durability", 400),
                    (float) Json.f(o, "speed", 6), (float) Json.f(o, "damage", 2), Json.i(o, "enchant", 14), itemTag("repair_" + id)));
        }
    }

    // ------------------------------------------------------------ helpers
    private static <T extends Item> T regItem(String name, Function<Item.Properties, T> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Ids.id(name));
        T item = factory.apply(props.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        ITEMS.put(name, item);
        return item;
    }

    private static SoundType sound(String s) {
        return switch (s) {
            case "glass" -> SoundType.GLASS;
            case "coral" -> SoundType.CORAL_BLOCK;
            case "plant" -> SoundType.WET_GRASS;
            case "sand" -> SoundType.SAND;
            case "basalt" -> SoundType.BASALT;
            case "amethyst" -> SoundType.AMETHYST;
            case "metal" -> SoundType.METAL;
            default -> SoundType.STONE;
        };
    }

    // ------------------------------------------------------------ bloques
    private static void registerBlocks() {
        for (JsonElement e : Data.arr("blocks")) {
            JsonObject o = e.getAsJsonObject();
            String name = Json.s(o, "id");
            String kind = Json.s(o, "kind", "basic");
            ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Ids.id(name));
            final int light = Json.i(o, "light", 0);
            BlockBehaviour.Properties p = BlockBehaviour.Properties.of()
                    .strength((float) Json.f(o, "hardness", 1.5), (float) Json.f(o, "resistance", 6))
                    .sound(sound(Json.s(o, "sound", "stone")))
                    .lightLevel(st -> light);
            if (Json.b(o, "needs_tool")) p = p.requiresCorrectToolForDrops();
            if (Json.b(o, "no_collision")) p = p.noCollission();
            if (Json.b(o, "no_occlusion")) p = p.noOcclusion();
            p = p.setId(key);
            Block b = switch (kind) {
                case "plant" -> new WaterBlock(p, net.minecraft.world.level.block.Block.box(4, 0, 4, 12, 16, 12));
                case "small" -> new WaterBlock(p, net.minecraft.world.level.block.Block.box(5, 0, 5, 11, 10, 11));
                case "vent" -> new VentBlock(p);
                case "portal" -> new PortalBlock(p);
                default -> new Block(p);
            };
            Registry.register(BuiltInRegistries.BLOCK, key, b);
            BLOCKS.put(name, b);
            final Block fb = b;
            regItem(name, ip -> new BlockItem(fb, ip), new Item.Properties().useBlockDescriptionPrefix());
        }
    }

    // ------------------------------------------------------------ items
    private static void registerItems() {
        for (JsonElement e : Data.arr("items")) {
            JsonObject o = e.getAsJsonObject();
            String name = Json.s(o, "id");
            String kind = Json.s(o, "kind", "basic");
            Item.Properties p = new Item.Properties();
            if (Json.b(o, "foil")) p = p.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
            if (Json.b(o, "rare")) p = p.rarity(Rarity.RARE);
            Function<Item.Properties, Item> f;
            switch (kind) {
                case "food" -> {
                    p = p.food(new FoodProperties.Builder().nutrition(Json.i(o, "nutrition", 4))
                            .saturationModifier((float) Json.f(o, "sat", 0.3)).build());
                    f = Item::new;
                }
                case "armor" -> {
                    String set = Json.s(o, "set");
                    ArmorType type = switch (Json.s(o, "slot")) {
                        case "head" -> ArmorType.HELMET;
                        case "chest" -> ArmorType.CHESTPLATE;
                        case "legs" -> ArmorType.LEGGINGS;
                        default -> ArmorType.BOOTS;
                    };
                    p = p.humanoidArmor(ARMOR_MATS.get(set), type);
                    f = Item::new;
                }
                case "sword" -> {
                    p = p.sword(TOOL_MATS.get(Json.s(o, "mat")), (float) Json.f(o, "dmg", 3), (float) Json.f(o, "spd", -2.4));
                    f = Item::new;
                }
                case "trident" -> {
                    p = p.durability(Json.i(o, "durability", 500)).attributes(TridentItem.createAttributes())
                            .component(DataComponents.TOOL, TridentItem.createToolProperties()).enchantable(Json.i(o, "enchant", 1));
                    f = TridentItem::new;
                }
                case "crossbow" -> {
                    p = p.durability(Json.i(o, "durability", 600)).enchantable(1);
                    f = CrossbowItem::new;
                }
                case "oxygen" -> f = SpecialItems.Oxygen::new;
                case "key" -> f = SpecialItems.Key::new;
                case "heart" -> f = SpecialItems.Heart::new;
                default -> f = Item::new;
            }
            Item it = regItem(name, f, p);
            if ("armor".equals(kind)) {
                String set = Json.s(o, "set");
                ARMOR_SET.put(it, set);
                PRESSURE.put(it, SET_PRESSURE.getOrDefault(set, 1));
            }
        }
    }

    // ------------------------------------------------------------ entidades
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void registerEntities() {
        for (JsonElement e : Data.arr("species")) {
            JsonObject sp = e.getAsJsonObject();
            String id = Json.s(sp, "id");
            SPECIES.put(id, sp);
            MobCategory cat = switch (Json.s(sp, "cat")) {
                case "monster" -> MobCategory.MONSTER;
                case "water_ambient" -> MobCategory.WATER_AMBIENT;
                default -> MobCategory.WATER_CREATURE;
            };
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Ids.id(id));
            EntityType<?> type;
            if (Json.b(sp, "boss")) {
                EntityType.Builder<LeviathanEntity> b = EntityType.Builder.<LeviathanEntity>of(LeviathanEntity::new, cat)
                        .sized((float) Json.f(sp, "w", 4), (float) Json.f(sp, "h", 3)).clientTrackingRange(16).updateInterval(2).fireImmune();
                type = b.build(key);
                Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
                FabricDefaultAttributeRegistry.register((EntityType<? extends LivingEntity>) type, LeviathanEntity.attrs(sp));
            } else {
                EntityType.Builder<SeaCreature> b = EntityType.Builder.<SeaCreature>of((t, l) -> new SeaCreature(t, l, sp), cat)
                        .sized((float) Json.f(sp, "w", 1), (float) Json.f(sp, "h", 1)).clientTrackingRange(8).updateInterval(2);
                if (Json.b(sp, "fire")) b = b.fireImmune();
                type = b.build(key);
                Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
                FabricDefaultAttributeRegistry.register((EntityType<? extends LivingEntity>) type, SeaCreature.attrs(sp));
            }
            ENTITIES.put(id, type);
        }
    }

    // ------------------------------------------------------------ worldgen
    private static void registerFeatures() {
        Registry.register(BuiltInRegistries.FEATURE, Ids.id("sunken_city"), new SunkenCityFeature());
        Registry.register(BuiltInRegistries.FEATURE, Ids.id("shipwreck"), new ShipwreckFeature());
        Registry.register(BuiltInRegistries.FEATURE, Ids.id("sanctuary"), new SanctuaryFeature());
        Registry.register(BuiltInRegistries.FEATURE, Ids.id("volcano"), new VolcanoFeature());
    }

    // ------------------------------------------------------------ pestaña creativa
    private static void registerTab() {
        ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB, Ids.id("abismo"));
        CreativeModeTab tab = FabricCreativeModeTab.builder()
                .icon(() -> new ItemStack(ITEMS.get("nucleo_oceanico")))
                .title(Component.translatable("creativeTab.abismo_oceanico"))
                .displayItems((params, output) -> {
                    for (Item it : ITEMS.values()) output.accept(it);
                }).build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
    }
}
