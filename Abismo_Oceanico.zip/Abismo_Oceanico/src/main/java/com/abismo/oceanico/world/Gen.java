package com.abismo.oceanico.world;

import com.abismo.oceanico.Ids;
import com.abismo.oceanico.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;

/** Utilidad para construir estructuras dentro de la region de generacion (sin salirse de ella). */
final class Gen {
    final WorldGenLevel lv;
    final RandomSource r;
    static final BlockState WATER = Blocks.WATER.defaultBlockState();
    static final BlockState AIR = Blocks.AIR.defaultBlockState();

    Gen(WorldGenLevel lv, RandomSource r) { this.lv = lv; this.r = r; }

    static BlockState b(String name) { return ModRegistry.BLOCKS.get(name).defaultBlockState(); }

    void put(int x, int y, int z, BlockState s) {
        BlockPos p = new BlockPos(x, y, z);
        if (y < lv.getMinY() || y >= lv.getMaxY()) return;
        if (lv.ensureCanWrite(p)) lv.setBlock(p, s, 2);
    }

    void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) put(x, y, z, s);
    }

    /** caja hueca: paredes/suelo/techo de "wall"; interior con AIRE (se puede respirar). */
    void hollow(int x1, int y1, int z1, int x2, int y2, int z2, BlockState wall) {
        box(x1, y1, z1, x2, y2, z2, wall);
        box(x1 + 1, y1 + 1, z1 + 1, x2 - 1, y2 - 1, z2 - 1, AIR);
    }

    void chest(int x, int y, int z, String loot) {
        put(x, y, z, Blocks.CHEST.defaultBlockState().setValue(net.minecraft.world.level.block.ChestBlock.WATERLOGGED, false));
        BlockPos p = new BlockPos(x, y, z);
        BlockEntity be = lv.getBlockEntity(p);
        if (be instanceof RandomizableContainer rc) rc.setLootTable(ResourceKey.create(Registries.LOOT_TABLE, Ids.id("chests/" + loot)), r.nextLong());
    }

    /** Puerta de madera doble altura (el agua nunca entra en el hueco de una puerta, asi el interior sigue seco). */
    void door(int x, int y, int z, net.minecraft.core.Direction facing) {
        BlockState lower = Blocks.SPRUCE_DOOR.defaultBlockState().setValue(net.minecraft.world.level.block.DoorBlock.FACING, facing)
                .setValue(net.minecraft.world.level.block.DoorBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER);
        put(x, y, z, lower);
        put(x, y + 1, z, lower.setValue(net.minecraft.world.level.block.DoorBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
    }

    void spawner(int x, int y, int z, String species) {
        put(x, y, z, Blocks.SPAWNER.defaultBlockState());
        BlockEntity be = lv.getBlockEntity(new BlockPos(x, y, z));
        EntityType<?> t = ModRegistry.ENTITIES.get(species);
        if (be instanceof SpawnerBlockEntity sbe && t != null) sbe.setEntityId(t, r);
    }

    /** limpia terreno sobresaliente y rellena cimientos. */
    void level(int cx, int cz, int half, int y0, BlockState found) {
        for (int x = cx - half; x <= cx + half; x++)
            for (int z = cz - half; z <= cz + half; z++) {
                for (int y = y0; y <= y0 + 26; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (lv.ensureCanWrite(p) && lv.getBlockState(p).canOcclude()) lv.setBlock(p, WATER, 2);
                }
                for (int y = y0 - 1; y >= y0 - 14; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!lv.ensureCanWrite(p)) break;
                    if (y < y0 - 1 && lv.getBlockState(p).canOcclude()) break;
                    lv.setBlock(p, found, 2);
                }
            }
    }
}
