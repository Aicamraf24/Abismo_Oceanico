package com.abismo.oceanico.entity;

import com.abismo.oceanico.Json;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.navigation.AmphibiousPathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/**
 * Criatura marina generica y data-driven (anatomia/IA/estadisticas en abismo_data.json).
 * Extiende Animal para poder reproducirse; los depredadores tambien se reproducen.
 */
public class SeaCreature extends Animal {
    private final JsonObject sp;
    private final String ability;
    private final boolean bottom, amphibious, glow;
    private final List<Item> food = new ArrayList<>();
    private final int cap;
    private int dry, cd;

    public SeaCreature(EntityType<? extends SeaCreature> type, Level level, JsonObject sp) {
        super(type, level);
        this.sp = sp;
        this.ability = Json.s(sp, "ability", "none");
        this.bottom = Json.b(sp, "bottom");
        this.amphibious = Json.b(sp, "amphibious");
        this.glow = Json.b(sp, "glow");
        this.cap = Json.i(sp, "cap", 6);
        for (JsonElement e : sp.getAsJsonArray("food")) food.add(BuiltInRegistries.ITEM.getValue(Identifier.parse(e.getAsString())));
        if (bottom) {
            this.navigation = new AmphibiousPathNavigation(this, level);
            this.setPathfindingMalus(PathType.WATER, 0.0F);
        } else {
            this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02F, 0.1F, true);
            this.lookControl = new SmoothSwimmingLookControl(this, 10);
            this.navigation = new WaterBoundPathNavigation(this, level);
        }
        if (!level.isClientSide()) initGoals();   // la IA solo existe en el servidor (BreedGoal pide ServerLevel)
    }

    public static AttributeSupplier.Builder attrs(JsonObject sp) {
        return Animal.createAnimalAttributes()
                .add(Attributes.MAX_HEALTH, Json.f(sp, "hp", 20))
                .add(Attributes.MOVEMENT_SPEED, Json.f(sp, "spd", 1.0))
                .add(Attributes.ATTACK_DAMAGE, Json.f(sp, "dmg", 0))
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.ARMOR, Json.f(sp, "armor", 0))
                .add(Attributes.KNOCKBACK_RESISTANCE, Json.f(sp, "kbres", 0));
    }

    // ------------------------------------------------------------------ IA
    private void initGoals() {
        String beh = Json.s(sp, "beh");
        double dmg = Json.f(sp, "dmg", 0);
        if (dmg > 0) goalSelector.addGoal(1, new MeleeAttackGoal(this, bottom ? 1.0 : 1.3, true));
        if (beh.equals("skittish")) goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 14.0F, 1.2, 1.7));
        if (beh.equals("passive") || beh.equals("skittish") || beh.equals("neutral")) goalSelector.addGoal(1, new PanicGoal(this, 1.6));
        goalSelector.addGoal(2, new BreedGoal(this, 1.0));
        goalSelector.addGoal(3, new TemptGoal(this, 1.1, stack -> isFood(stack), false));
        goalSelector.addGoal(4, new FollowParentGoal(this, 1.1));
        goalSelector.addGoal(6, bottom ? new RandomStrollGoal(this, 0.8, 80) : new RandomSwimmingGoal(this, 1.0, 40));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        switch (beh) {
            case "hostile" -> {
                targetSelector.addGoal(1, new HurtByTargetGoal(this));
                targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
            }
            case "territorial" -> {
                targetSelector.addGoal(1, new HurtByTargetGoal(this));
                targetSelector.addGoal(2, new Territorial(this, 7.0));
            }
            case "neutral" -> targetSelector.addGoal(1, new HurtByTargetGoal(this));
            default -> {}
        }
        if (Json.b(sp, "hunts")) targetSelector.addGoal(3, new HuntGoal(this));
    }

    /** Ataca a jugadores solo cuando se acercan a su territorio. */
    private static class Territorial extends NearestAttackableTargetGoal<Player> {
        private final double r;
        Territorial(Mob mob, double r) { super(mob, Player.class, true); this.r = r; }
        @Override protected double getFollowDistance() { return r; }
    }

    /** Caza presas pequeñas (criaturas WATER_AMBIENT) para el comportamiento de depredador. */
    private static class HuntGoal extends TargetGoal {
        private LivingEntity prey;
        HuntGoal(Mob mob) { super(mob, false); this.setFlags(EnumSet.of(Goal.Flag.TARGET)); }

        @Override public boolean canUse() {
            if (mob.getRandom().nextInt(20) != 0) return false;
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(14.0),
                    x -> x.isAlive() && x != mob && x.getType().getCategory() == MobCategory.WATER_AMBIENT)) {
                double d = mob.distanceToSqr(e);
                if (d < bd) { bd = d; best = e; }
            }
            prey = best;
            return prey != null;
        }

        @Override public void start() { mob.setTarget(prey); super.start(); }
    }

    // ------------------------------------------------------------------ movimiento
    @Override
    public void travel(Vec3 v) {
        if (!bottom && isEffectiveAi() && isInWater()) {
            moveRelative(getSpeed(), v);
            move(MoverType.SELF, getDeltaMovement());
            setDeltaMovement(getDeltaMovement().scale(0.9));
            if (getTarget() == null) setDeltaMovement(getDeltaMovement().add(0.0, -0.005, 0.0));
        } else {
            super.travel(v);
        }
    }

    @Override public boolean isPushedByFluid() { return bottom; }
    @Override public boolean canBreatheUnderwater() { return true; }

    // ------------------------------------------------------------------ reproduccion
    @Override
    public boolean isFood(ItemStack stack) { return food.contains(stack.getItem()); }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        Entity e = getType().create(level, EntitySpawnReason.BREEDING);
        if (e instanceof SeaCreature baby) {
            baby.setPersistenceRequired();
            return baby;
        }
        return null;
    }

    @Override
    public boolean canFallInLove() {
        if (!super.canFallInLove()) return false;
        // limite local de poblacion para cuidar el rendimiento
        return level().getEntitiesOfClass(SeaCreature.class, getBoundingBox().inflate(48.0), e -> e.getType() == getType()).size() < cap;
    }

    @Override
    public void setInLove(Player player) {
        super.setInLove(player);
        setPersistenceRequired();
    }

    @Override
    public boolean removeWhenFarAway(double dist) { return !hasCustomName() && !isPersistenceRequired() && !isInLove(); }

    // ------------------------------------------------------------------ combate y habilidades
    private float dmg() { return (float) getAttributeValue(Attributes.ATTACK_DAMAGE); }

    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean r = super.doHurtTarget(level, target);
        if (r && target instanceof LivingEntity le) {
            switch (ability) {
                case "poison" -> le.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
                case "ink" -> le.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
                case "slam" -> { le.setDeltaMovement(le.getDeltaMovement().add(0, 0.7, 0)); le.hurtMarked = true; }
                case "sweep" -> le.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 2));
                default -> {}
            }
        }
        return r;
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource src, float amt) {
        boolean r = super.hurtServer(level, src, amt);
        if (r) {
            Entity at = src.getEntity();
            switch (ability) {
                case "ink" -> {
                    if (cd <= 0) {
                        level.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + getBbHeight() / 2, getZ(), 30, 0.6, 0.4, 0.6, 0.05);
                        if (at instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
                        cd = 100;
                    }
                }
                case "thorns" -> { if (at instanceof LivingEntity le) le.hurtServer(level, damageSources().thorns(this), 2.0F); }
                case "shell" -> addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 60, 1));
                default -> {}
            }
        }
        return r;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide()) {
            if (glow && random.nextInt(30) == 0) level().addParticle(ParticleTypes.GLOW, getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0, 0.01, 0);
            return;
        }
        ServerLevel sl = (ServerLevel) level();
        if (!amphibious && !isInWater()) {
            if (++dry > 200 && dry % 20 == 0) hurtServer(sl, damageSources().dryOut(), 1.0F);
        } else dry = 0;
        if (cd > 0) cd--;
        abilityTick(sl);
    }

    private void abilityTick(ServerLevel sl) {
        LivingEntity t = getTarget();
        switch (ability) {
            case "shock" -> { if (t != null && t.isAlive() && tickCount % 60 == 0 && distanceToSqr(t) < 49) aoe(sl, 4.5, 0.8F); }
            case "sweep" -> { if (t != null && t.isAlive() && tickCount % 50 == 0 && distanceToSqr(t) < 64) aoe(sl, 6.0, 0.6F); }
            case "pressure_wave" -> { if (t != null && t.isAlive() && tickCount % 100 == 0 && distanceToSqr(t) < 144) aoe(sl, 9.0, 0.5F); }
            case "charge" -> { if (t != null && tickCount % 120 == 0) addEffect(new MobEffectInstance(MobEffects.SPEED, 50, 2)); }
            case "contact" -> {
                if (tickCount % 20 == 0) {
                    for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.35))) {
                        if (p.isCreative() || p.isSpectator()) continue;
                        p.hurtServer(sl, damageSources().mobAttack(this), 2.0F);
                        p.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0));
                    }
                }
            }
            default -> {}
        }
    }

    private void aoe(ServerLevel sl, double r, float factor) {
        boolean wave = ability.equals("pressure_wave"), sweep = ability.equals("sweep"), shock = ability.equals("shock");
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r),
                x -> x != this && !(x instanceof SeaCreature) && !(x instanceof LeviathanEntity)
                        && !(x instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            e.hurtServer(sl, damageSources().mobAttack(this), dmg() * factor);
            Vec3 d = e.position().subtract(position()).normalize();
            if (wave) e.setDeltaMovement(d.x * 1.1, 0.35, d.z * 1.1);
            if (sweep) e.setDeltaMovement(-d.x * 0.6, 0.1, -d.z * 0.6);
            if (shock) e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 1));
            e.hurtMarked = true;
        }
        sl.sendParticles(shock ? ParticleTypes.ELECTRIC_SPARK : wave ? ParticleTypes.BUBBLE_POP : ParticleTypes.SQUID_INK,
                getX(), getY() + getBbHeight() / 2, getZ(), 40, r * 0.4, 0.5, r * 0.4, 0.05);
    }
}
