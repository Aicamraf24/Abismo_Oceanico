package com.abismo.oceanico.client;

import com.abismo.oceanico.Json;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Modelo generico: la anatomia completa de cada especie se lee de abismo_data.json.
 * Las animaciones (natacion, tentaculos, mandibula, patas, pulso...) son procedurales y baratas.
 */
public class SpeciesModel extends EntityModel<SeaState> {
    private record Pt(ModelPart part, String anim, float amp, float spd, float ph, float rx, float ry, float rz) {}

    private final List<Pt> pts = new ArrayList<>();

    public SpeciesModel(ModelPart root, JsonObject sp) {
        super(root);
        Map<String, ModelPart> byName = new HashMap<>();
        for (JsonElement e : sp.getAsJsonObject("model").getAsJsonArray("parts")) {
            JsonObject o = e.getAsJsonObject();
            String name = Json.s(o, "name");
            String parent = o.get("parent").isJsonNull() ? null : Json.s(o, "parent");
            ModelPart part = parent == null ? root.getChild(name) : byName.get(parent).getChild(name);
            byName.put(name, part);
            JsonArray rot = o.getAsJsonArray("rot");
            String anim = o.get("anim").isJsonNull() ? "" : Json.s(o, "anim");
            pts.add(new Pt(part, anim, (float) Json.f(o, "amp", 0), (float) Json.f(o, "spd", 1), (float) Json.f(o, "ph", 0),
                    rot.get(0).getAsFloat(), rot.get(1).getAsFloat(), rot.get(2).getAsFloat()));
        }
    }

    public static LayerDefinition layer(JsonObject sp) {
        JsonObject m = sp.getAsJsonObject("model");
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        Map<String, PartDefinition> defs = new HashMap<>();
        for (JsonElement e : m.getAsJsonArray("parts")) {
            JsonObject o = e.getAsJsonObject();
            JsonArray off = o.getAsJsonArray("offset"), box = o.getAsJsonArray("box"), uv = o.getAsJsonArray("uv"), rot = o.getAsJsonArray("rot");
            CubeListBuilder cb = CubeListBuilder.create().texOffs(uv.get(0).getAsInt(), uv.get(1).getAsInt())
                    .addBox(box.get(0).getAsFloat(), box.get(1).getAsFloat(), box.get(2).getAsFloat(),
                            box.get(3).getAsFloat(), box.get(4).getAsFloat(), box.get(5).getAsFloat());
            PartPose pose = PartPose.offsetAndRotation(off.get(0).getAsFloat(), off.get(1).getAsFloat(), off.get(2).getAsFloat(),
                    rot.get(0).getAsFloat(), rot.get(1).getAsFloat(), rot.get(2).getAsFloat());
            PartDefinition parent = o.get("parent").isJsonNull() ? root : defs.get(Json.s(o, "parent"));
            defs.put(Json.s(o, "name"), parent.addOrReplaceChild(Json.s(o, "name"), cb, pose));
        }
        return LayerDefinition.create(mesh, m.get("tw").getAsInt(), m.get("th").getAsInt());
    }

    @Override
    public void setupAnim(SeaState s) {
        super.setupAnim(s);
        float t = s.ageInTicks;
        float walk = Math.min(1.0F, s.walkAnimationSpeed * 2.0F);
        float pos = s.walkAnimationPos;
        float atk = s.attack;
        for (Pt p : pts) {
            ModelPart m = p.part;
            m.xRot = p.rx; m.yRot = p.ry; m.zRot = p.rz;
            m.xScale = 1.0F; m.yScale = 1.0F; m.zScale = 1.0F;
            float w = t * 0.30F * p.spd + p.ph;
            switch (p.anim) {
                case "yaw" -> m.yRot += Mth_sin(w) * p.amp * (0.5F + walk);
                case "pitch" -> m.xRot += Mth_sin(w) * p.amp * (0.6F + walk * 0.6F);
                case "roll" -> m.zRot += Mth_sin(w) * p.amp * (0.6F + walk * 0.8F);
                case "tent" -> { m.xRot += Mth_sin(w) * p.amp - atk * 0.7F; m.yRot += Mth_cos(w * 0.8F) * p.amp * 0.5F; }
                case "tentv" -> { m.xRot += Mth_sin(w) * p.amp; m.zRot += Mth_cos(w * 0.9F) * p.amp * 0.6F; }
                case "jaw" -> m.xRot += Mth_sin(w) * p.amp * 0.12F + atk * p.amp * 1.4F;
                case "leg" -> m.xRot += Mth_cos(pos * 0.6662F + p.ph) * p.amp * walk;
                case "armswing" -> m.xRot += Mth_cos(pos * 0.6662F + p.ph) * p.amp * walk - atk * 1.8F;
                case "claw" -> { m.yRot += Mth_sin(w) * p.amp * 0.5F; m.xRot -= atk * 0.8F; }
                case "pulse" -> { float k = Mth_sin(t * 0.25F * p.spd) * p.amp; m.xScale = 1.0F + k; m.zScale = 1.0F + k; m.yScale = 1.0F - k * 1.2F; }
                default -> {}
            }
        }
    }

    private static float Mth_sin(float v) { return (float) Math.sin(v); }
    private static float Mth_cos(float v) { return (float) Math.cos(v); }
}
