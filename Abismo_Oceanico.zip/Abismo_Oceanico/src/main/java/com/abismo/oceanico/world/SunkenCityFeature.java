package com.abismo.oceanico.world;

import com.mojang.serialization.Codec;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import static com.abismo.oceanico.world.Gen.b;

/** Ciudad hundida: palacio, torres, templos, bibliotecas, laboratorios, carceles, estatuas, puentes y camara secreta. */
public class SunkenCityFeature extends Feature<NoneFeatureConfiguration> {
    public SunkenCityFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        RandomSource r = ctx.random();
        Gen g = new Gen(lv, r);
        int cx = ctx.origin().getX(), cz = ctx.origin().getZ(), y0 = ctx.origin().getY();
        int size = r.nextInt(3);                 // 0 pequeña, 1 mediana, 2 grande
        int half = 9 + size * 3;                  // 9..15
        BlockState brick = b("ladrillo_abisal"), stone = b("piedra_abisal");
        g.level(cx, cz, half, y0, stone);
        // plaza empedrada
        for (int x = cx - half; x <= cx + half; x++)
            for (int z = cz - half; z <= cz + half; z++)
                g.put(x, y0 - 1, z, ((x + z) & 1) == 0 ? brick : stone);
        // avenidas
        for (int i = -half; i <= half; i++) { g.put(cx + i, y0 - 1, cz, b("ladrillo_abisal_tallado")); g.put(cx, y0 - 1, cz + i, b("ladrillo_abisal_tallado")); }
        // edificios en cuadricula (el centro queda para el palacio)
        int[] off = {-half + 4, half - 4};
        String[] kinds = {"tower", "temple", "library", "lab", "prison", "garden"};
        int[][] towers = new int[4][];
        int k = 0;
        for (int ix = 0; ix < 2; ix++)
            for (int iz = 0; iz < 2; iz++) {
                int bx = cx + off[ix], bz = cz + off[iz];
                String kind = kinds[r.nextInt(kinds.length)];
                if (k == 0 && size > 0) kind = "tower";
                switch (kind) {
                    case "tower" -> tower(g, bx, y0, bz, 2 + r.nextInt(2), 12 + r.nextInt(8));
                    case "temple" -> temple(g, bx, y0, bz);
                    case "library" -> library(g, bx, y0, bz);
                    case "lab" -> lab(g, bx, y0, bz);
                    case "prison" -> prison(g, bx, y0, bz);
                    default -> garden(g, bx, y0, bz);
                }
                towers[k++] = new int[]{bx, bz};
            }
        // puentes entre edificios vecinos
        if (size > 0) {
            int by = y0 + 9;
            bridge(g, towers[0][0], towers[0][1], towers[1][0], towers[1][1], by);
            bridge(g, towers[2][0], towers[2][1], towers[3][0], towers[3][1], by);
        }
        // palacio central
        if (size == 0) shrine(g, cx, y0, cz); else palace(g, cx, y0, cz, size);
        // estatuas de criaturas marinas
        statue(g, cx - half + 1, y0, cz);
        statue(g, cx + half - 1, y0, cz);
        return true;
    }

    // --------------------------------------------------------------- edificios
    static void tower(Gen g, int cx, int y0, int cz, int w, int h) {
        BlockState brick = b("ladrillo_abisal"), glass = b("vidrio_abisal"), lamp = b("lampara_marina");
        g.hollow(cx - w, y0, cz - w, cx + w, y0 + h, cz + w, brick);
        for (int y = y0 + 3; y < y0 + h; y += 4) {
            for (int s = -w + 1; s <= w - 1; s++) {
                g.put(cx + s, y, cz - w, glass); g.put(cx + s, y, cz + w, glass);
                g.put(cx - w, y, cz + s, glass); g.put(cx + w, y, cz + s, glass);
            }
        }
        for (int y = y0 + 5; y < y0 + h; y += 5) {
            g.box(cx - w + 1, y, cz - w + 1, cx + w - 1, y, cz + w - 1, brick);
            g.box(cx, y, cz, cx + (w > 1 ? 1 : 0), y, cz, Gen.WATER);
            g.put(cx - w + 1, y + 1, cz - w + 1, lamp);
        }
        g.box(cx, y0, cz - w, cx, y0 + 2, cz - w, Gen.WATER); // puerta
        for (int i = 0; i <= w + 1; i++) g.box(cx - w - 1 + i, y0 + h + 1 + i, cz - w - 1 + i, cx + w + 1 - i, y0 + h + 1 + i, cz + w + 1 - i, b("ladrillo_abisal_tallado"));
        g.put(cx, y0 + h + w + 3, cz, lamp);
        g.chest(cx, y0 + h - 4 + 1, cz + 1, "city_common");
    }

    static void temple(Gen g, int cx, int y0, int cz) {
        BlockState pil = b("pilar_abisal"), brick = b("ladrillo_abisal");
        g.box(cx - 4, y0, cz - 4, cx + 4, y0, cz + 4, brick);
        for (int dx : new int[]{-4, 4}) for (int dz : new int[]{-4, -2, 0, 2, 4}) g.box(cx + dx, y0 + 1, cz + dz, cx + dx, y0 + 6, cz + dz, pil);
        g.box(cx - 5, y0 + 7, cz - 5, cx + 5, y0 + 7, cz + 5, brick);
        g.box(cx - 3, y0 + 8, cz - 3, cx + 3, y0 + 8, cz + 3, b("ladrillo_abisal_tallado"));
        g.put(cx, y0 + 1, cz, b("altar_abisal"));
        g.put(cx, y0 + 2, cz, b("lampara_marina"));
        g.chest(cx, y0 + 1, cz + 2, "city_common");
        g.put(cx, y0 + 9, cz, b("coral_luminoso_azul"));
    }

    static void library(Gen g, int cx, int y0, int cz) {
        BlockState brick = b("ladrillo_abisal");
        g.hollow(cx - 4, y0, cz - 4, cx + 4, y0 + 6, cz + 4, brick);
        for (int s = -3; s <= 3; s++) {
            for (int y = y0 + 1; y <= y0 + 4; y++) { g.put(cx + s, y, cz - 3, Blocks.BOOKSHELF.defaultBlockState()); g.put(cx + s, y, cz + 3, Blocks.BOOKSHELF.defaultBlockState()); }
        }
        g.box(cx, y0, cz - 4, cx, y0 + 2, cz - 4, Gen.WATER);
        g.put(cx, y0 + 1, cz, Blocks.LECTERN.defaultBlockState());
        g.put(cx - 2, y0 + 5, cz, b("lampara_marina")); g.put(cx + 2, y0 + 5, cz, b("lampara_marina"));
        g.chest(cx + 3, y0 + 1, cz, "city_rare");
    }

    static void lab(Gen g, int cx, int y0, int cz) {
        BlockState brick = b("ladrillo_abisal"), glass = b("vidrio_abisal");
        g.hollow(cx - 5, y0, cz - 4, cx + 5, y0 + 5, cz + 4, brick);
        for (int s = -3; s <= 3; s += 3) {
            g.box(cx + s, y0 + 1, cz + 2, cx + s, y0 + 3, cz + 2, glass);
            g.put(cx + s, y0 + 2, cz + 2, b("cristal_bioluminiscente_ore"));
        }
        g.box(cx, y0, cz - 4, cx, y0 + 2, cz - 4, Gen.WATER);
        g.put(cx - 4, y0 + 1, cz - 3, Blocks.BREWING_STAND.defaultBlockState());
        g.put(cx + 4, y0 + 4, cz, b("lampara_marina"));
        g.chest(cx + 4, y0 + 1, cz - 3, "city_rare");
    }

    static void prison(Gen g, int cx, int y0, int cz) {
        BlockState brick = b("ladrillo_abisal_musgoso");
        g.hollow(cx - 5, y0, cz - 4, cx + 5, y0 + 5, cz + 4, brick);
        for (int s : new int[]{-3, 0, 3}) {
            g.box(cx + s - 1, y0 + 1, cz + 1, cx + s + 1, y0 + 3, cz + 1, Blocks.IRON_BARS.defaultBlockState());
            g.box(cx + s - 1, y0 + 1, cz + 3, cx + s + 1, y0 + 3, cz + 3, Gen.WATER);
        }
        g.box(cx, y0, cz - 4, cx, y0 + 2, cz - 4, Gen.WATER);
        g.spawner(cx, y0 + 1, cz - 2, "guardian_coralino");
        g.chest(cx, y0 + 1, cz + 3, "city_common");
    }

    static void garden(Gen g, int cx, int y0, int cz) {
        BlockState brick = b("ladrillo_abisal");
        g.box(cx - 3, y0, cz - 3, cx + 3, y0, cz + 3, brick);
        for (int i = 0; i < 6; i++) {
            int x = cx - 2 + g.r.nextInt(5), z = cz - 2 + g.r.nextInt(5);
            String c = new String[]{"coral_luminoso_azul", "coral_luminoso_rosa", "coral_luminoso_violeta", "coral_luminoso_naranja"}[g.r.nextInt(4)];
            g.box(x, y0 + 1, z, x, y0 + 1 + g.r.nextInt(4), z, b(c));
        }
        g.put(cx, y0 + 1, cz, b("planta_luminosa"));
    }

    static void shrine(Gen g, int cx, int y0, int cz) {
        BlockState brick = b("ladrillo_abisal"), pil = b("pilar_abisal");
        g.box(cx - 3, y0, cz - 3, cx + 3, y0, cz + 3, b("ladrillo_abisal_tallado"));
        for (int dx : new int[]{-3, 3}) for (int dz : new int[]{-3, 3}) g.box(cx + dx, y0 + 1, cz + dz, cx + dx, y0 + 5, cz + dz, pil);
        g.box(cx - 3, y0 + 6, cz - 3, cx + 3, y0 + 6, cz + 3, brick);
        g.put(cx, y0 + 1, cz, b("lampara_marina"));
        g.chest(cx, y0 + 1, cz + 1, "city_rare");
    }

    static void palace(Gen g, int cx, int y0, int cz, int size) {
        BlockState brick = b("ladrillo_abisal"), tall = b("ladrillo_abisal_tallado"), glass = b("vidrio_abisal"), lamp = b("lampara_marina");
        int w = 6, h = 11;
        g.hollow(cx - w, y0, cz - w, cx + w, y0 + h, cz + w, brick);
        for (int y = y0 + 3; y < y0 + h - 1; y += 4)
            for (int s = -w + 2; s <= w - 2; s += 2) {
                g.put(cx + s, y, cz - w, glass); g.put(cx + s, y, cz + w, glass); g.put(cx - w, y, cz + s, glass); g.put(cx + w, y, cz + s, glass);
            }
        g.box(cx - 1, y0, cz - w, cx + 1, y0 + 4, cz - w, Gen.WATER); // gran portal
        // salon real: trono + columnas
        g.box(cx - 1, y0 + 1, cz + w - 2, cx + 1, y0 + 1, cz + w - 1, tall);
        g.put(cx, y0 + 2, cz + w - 2, b("altar_abisal"));
        for (int s : new int[]{-4, 4}) for (int z = -3; z <= 3; z += 3) g.box(cx + s, y0 + 1, cz + z, cx + s, y0 + h - 1, cz + z, b("pilar_abisal"));
        // piso superior + cupula
        g.box(cx - w + 1, y0 + 6, cz - w + 1, cx + w - 1, y0 + 6, cz + w - 1, brick);
        g.box(cx - 1, y0 + 6, cz - 1, cx + 1, y0 + 6, cz + 1, Gen.WATER);
        for (int i = 0; i <= w; i++) g.box(cx - w + i, y0 + h + 1 + i, cz - w + i, cx + w - i, y0 + h + 1 + i, cz + w - i, i % 2 == 0 ? tall : brick);
        g.put(cx, y0 + h + w + 2, cz, lamp);
        g.chest(cx + 3, y0 + 7, cz + 3, "city_rare");
        // torres en las esquinas
        if (size > 0) for (int dx : new int[]{-w - 1, w + 1}) for (int dz : new int[]{-w - 1, w + 1}) tower(g, cx + dx, y0, cz + dz, 1, 15 + g.r.nextInt(5));
        // camara secreta bajo cristal en el suelo del salon (se ve el brillo)
        int vy = y0 - 9;
        g.hollow(cx - 4, vy, cz - 4, cx + 4, y0 - 2, cz + 4, tall);
        g.box(cx, y0 - 1, cz - 2, cx, y0 - 1, cz - 2, glass);
        g.box(cx, y0 - 1, cz - 2, cx, y0 - 1, cz - 2, glass);
        g.put(cx, y0 - 2, cz - 2, Gen.WATER); g.put(cx, y0 - 3, cz - 2, Gen.WATER);
        g.put(cx, y0, cz - 2, glass);
        g.put(cx - 3, vy + 1, cz - 3, lamp); g.put(cx + 3, vy + 1, cz + 3, lamp);
        g.chest(cx, vy + 1, cz + 3, "vault");
        g.chest(cx + 3, vy + 1, cz, "vault");
        g.spawner(cx, vy + 1, cz, size == 2 ? "golem_coral" : "guardian_coralino");
    }

    static void bridge(Gen g, int x1, int z1, int x2, int z2, int y) {
        BlockState brick = b("ladrillo_abisal"), pil = b("pilar_abisal");
        int dx = Integer.signum(x2 - x1), dz = Integer.signum(z2 - z1);
        int x = x1, z = z1;
        while (x != x2 || z != z2) {
            if (x != x2) x += dx; else if (z != z2) z += dz;
            g.box(x - (dz != 0 ? 1 : 0), y, z - (dx != 0 ? 1 : 0), x + (dz != 0 ? 1 : 0), y, z + (dx != 0 ? 1 : 0), brick);
            if (((x + z) & 3) == 0) { g.put(x - (dz != 0 ? 1 : 0), y + 1, z - (dx != 0 ? 1 : 0), pil); g.put(x + (dz != 0 ? 1 : 0), y + 1, z + (dx != 0 ? 1 : 0), pil); }
        }
    }

    /** estatua de tiburon con bloques tallados. */
    static void statue(Gen g, int cx, int y0, int cz) {
        BlockState t = b("ladrillo_abisal_tallado");
        g.box(cx - 1, y0, cz - 4, cx + 1, y0, cz + 4, b("pilar_abisal"));
        g.box(cx, y0 + 1, cz - 4, cx, y0 + 2, cz + 3, t);
        g.box(cx, y0 + 3, cz - 1, cx, y0 + 5, cz, t);
        g.put(cx, y0 + 2, cz + 4, t); g.put(cx, y0 + 3, cz - 4, t); g.put(cx, y0 + 4, cz - 5, t);
        g.put(cx - 1, y0 + 2, cz + 1, t); g.put(cx + 1, y0 + 2, cz + 1, t);
        g.put(cx, y0 + 3, cz + 2, b("cristal_bioluminiscente_ore"));
    }
}
