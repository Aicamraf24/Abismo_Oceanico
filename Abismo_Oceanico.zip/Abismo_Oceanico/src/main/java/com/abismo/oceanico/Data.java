package com.abismo.oceanico;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Carga abismo_data.json (especies, objetos, bloques, armaduras), generado junto con los recursos. */
public final class Data {
    public static JsonObject root;
    private Data() {}

    public static void load() {
        if (root != null) return;
        try (InputStream in = Data.class.getResourceAsStream("/abismo_data.json")) {
            if (in == null) throw new IllegalStateException("Falta abismo_data.json en el jar");
            root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            throw new RuntimeException("No se pudo leer abismo_data.json", e);
        }
    }

    public static JsonArray arr(String key) { return root.getAsJsonArray(key); }
}
