package com.abismo.oceanico;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbismoOceanico implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger(Ids.MOD_ID);

    @Override
    public void onInitialize() {
        Data.load();
        ModRegistry.registerAll();
        Survival.init();
        LOGGER.info("Abismo Oceánico cargado: {} objetos, {} bloques, {} especies",
                ModRegistry.ITEMS.size(), ModRegistry.BLOCKS.size(), ModRegistry.ENTITIES.size());
    }
}
