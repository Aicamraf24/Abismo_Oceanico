package com.abismo.oceanico;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sistemas de exploracion submarina (solo servidor, baratos): presion por profundidad, corrientes,
 * habilidades de armadura y tiempo en el portal.
 */
public final class Survival {
    private static final Map<UUID, Integer> IN_PORTAL = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private Survival() {}

    public static void actionBar(net.minecraft.world.entity.player.Player p, Component c) {
        if (p instanceof ServerPlayer sp) sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket(c));
    }

    public static void setPortalCooldown(ServerPlayer p) { COOLDOWN.put(p.getUUID(), 120); IN_PORTAL.remove(p.getUUID()); }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                tickPortal(p);
                if (p.tickCount % 10 == 0) tickArmor(p);
                if (p.level().dimension() == ModRegistry.ABYSS) {
                    if (p.tickCount % 20 == 0) tickPressure(p);
                    if (p.tickCount % 40 == 0) Populator.tick((ServerLevel) p.level(), p);
                    if (p.tickCount % 2 == 0) tickCurrent(p);
                }
            }
        });
    }

    private static void tickPortal(ServerPlayer p) {
        UUID id = p.getUUID();
        int cd = COOLDOWN.getOrDefault(id, 0);
        if (cd > 0) { COOLDOWN.put(id, cd - 1); return; }
        Block portal = ModRegistry.BLOCKS.get("portal_abisal");
        boolean inside = p.level().getBlockState(p.blockPosition()).is(portal) || p.level().getBlockState(p.blockPosition().above()).is(portal);
        if (!inside) { IN_PORTAL.remove(id); return; }
        int t = IN_PORTAL.merge(id, 1, Integer::sum);
        if (t >= 60) { IN_PORTAL.remove(id); PortalHelper.travel(p); }
    }

    /** puntos de presion que aportan las piezas puestas (0..24). */
    public static int pressureScore(ServerPlayer p) {
        int s = 0;
        for (EquipmentSlot slot : ARMOR) {
            ItemStack st = p.getItemBySlot(slot);
            s += ModRegistry.PRESSURE.getOrDefault(st.getItem(), 0);
        }
        return s;
    }

    private static int required(double y) {
        if (y < 150) return 20;  // Trinchera (~140 bloques bajo la superficie): armadura de Escamas o del Abismo completa
        if (y < 190) return 12;  // Fondo marino (~100 bloques): p. ej. Perla Abisal completa
        if (y < 235) return 6;   // Aguas medias (~55 bloques): Coral completa o piezas de otros conjuntos
        return 0;                // Cerca de la superficie: sin riesgo
    }

    private static void tickPressure(ServerPlayer p) {
        if (p.isCreative() || p.isSpectator()) return;
        int need = required(p.getY());
        int have = pressureScore(p);
        if (have >= need) return;
        actionBar(p, Component.translatable("msg.abismo_oceanico.pressure", need, have));
        p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 0, true, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 60, 0, true, false, false));
        // nunca mata: solo castiga mientras tengas mas de 3 corazones
        if (p.getHealth() > 6.0F) p.hurtServer((ServerLevel) p.level(), p.level().damageSources().magic(), 1.0F);
    }

    private static void tickCurrent(ServerPlayer p) {
        if (!p.isInWater() || p.isCreative() || p.isSpectator()) return;
        double t = p.level().getGameTime() * 0.004;
        double x = p.getX() * 0.02, z = p.getZ() * 0.02, y = p.getY() * 0.015;
        Vec3 v = new Vec3(Math.sin(x + t + y), 0.15 * Math.sin(z - t), Math.cos(z + t - y)).scale(0.012);
        p.setDeltaMovement(p.getDeltaMovement().add(v));
        p.hurtMarked = true;
    }

    private static void tickArmor(ServerPlayer p) {
        int[] count = new int[1];
        Map<String, Integer> sets = new HashMap<>();
        for (EquipmentSlot slot : ARMOR) {
            String set = ModRegistry.ARMOR_SET.get(p.getItemBySlot(slot).getItem());
            if (set != null) { sets.merge(set, 1, Integer::sum); count[0]++; }
        }
        if (count[0] == 0) return;
        boolean head = ModRegistry.ARMOR_SET.containsKey(p.getItemBySlot(EquipmentSlot.HEAD).getItem());
        boolean feet = ModRegistry.ARMOR_SET.containsKey(p.getItemBySlot(EquipmentSlot.FEET).getItem());
        boolean legs = ModRegistry.ARMOR_SET.containsKey(p.getItemBySlot(EquipmentSlot.LEGS).getItem());
        if (head) p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 260, 0, true, false, false));
        if (legs || feet) p.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 260, 0, true, false, false));
        // vision submarina: perla, guardian, leviatan y abismo (casco)
        String hs = ModRegistry.ARMOR_SET.get(p.getItemBySlot(EquipmentSlot.HEAD).getItem());
        if (hs != null && !hs.equals("coral")) p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false, false));
        // proteccion frente a ataques acuaticos: 2+ piezas de guardian/leviatan/abismo
        int strong = sets.getOrDefault("guardian", 0) + sets.getOrDefault("escamas_leviatan", 0) + sets.getOrDefault("abismo", 0);
        if (strong >= 2) p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 260, strong >= 4 ? 1 : 0, true, false, false));
    }
}
