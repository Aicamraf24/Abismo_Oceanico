package com.abismo.oceanico.client;

import com.abismo.oceanico.Ids;
import com.abismo.oceanico.Json;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

public class SeaRenderer<T extends Mob> extends MobRenderer<T, SeaState, SpeciesModel> {
    private final Identifier texture;
    private final float size;

    public SeaRenderer(EntityRendererProvider.Context ctx, JsonObject sp, ModelLayerLocation layer) {
        super(ctx, new SpeciesModel(ctx.bakeLayer(layer), sp), (float) Json.f(sp, "w", 1) * 0.4F);
        this.texture = Ids.id("textures/entity/" + Json.s(sp, "id") + ".png");
        this.size = (float) Json.f(sp, "render_scale", 1.0);
    }

    @Override
    public SeaState createRenderState() { return new SeaState(); }

    @Override
    public void extractRenderState(T entity, SeaState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.attack = entity.getAttackAnim(partialTick);
    }

    @Override
    public Identifier getTextureLocation(SeaState state) { return texture; }

    @Override
    protected void scale(SeaState state, PoseStack poseStack) {
        float s = size * (state.isBaby ? 0.55F : 1.0F);
        poseStack.scale(s, s, s);
    }
}
