package com.abismo.oceanico;

import com.abismo.oceanico.entity.LeviathanEntity;
import com.abismo.oceanico.entity.SeaCreature;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * Da vida a la dimension: alrededor de cada jugador hace aparecer criaturas en tres franjas (superficie, aguas medias y fondo),
 * en vez de depender solo del reparto aleatorio vanilla. Tiene limites por jugador y las criaturas desaparecen al alejarse.
 */
public final class Populator {
    private static final int SEA = 290;
    private static final int CAP_MONSTER = 12, CAP_CREATURE = 18, CAP_AMBIENT = 22;

    private record Entry(String id, int weight, int min, int max, MobCategory cat, String bands, boolean bottom) {}
    private static final Map<ResourceKey<Biome>, List<Entry>> TABLE = new LinkedHashMap<>();

    private Populator() {}

    private static void load() {
        JsonObject t = Data.root.getAsJsonObject("spawn_table");
        for (Map.Entry<String, JsonElement> e : t.entrySet()) {
            ResourceKey<Biome> key = ResourceKey.create(Registries.BIOME, Ids.id(e.getKey()));
            List<Entry> list = new ArrayList<>();
            for (JsonElement el : (JsonArray) e.getValue()) {
                JsonObject o = el.getAsJsonObject();
                String id = Json.s(o, "id");
                JsonObject sp = ModRegistry.SPECIES.get(id);
                if (sp == null) continue;
                MobCategory cat = switch (Json.s(sp, "cat")) {
                    case "monster" -> MobCategory.MONSTER;
                    case "water_ambient" -> MobCategory.WATER_AMBIENT;
                    default -> MobCategory.WATER_CREATURE;
                };
                list.add(new Entry(id, Json.i(o, "weight", 1), Json.i(o, "min", 1), Json.i(o, "max", 1), cat, Json.s(sp, "bands", "smb"), Json.b(sp, "bottom")));
            }
            TABLE.put(key, list);
        }
    }

    /** Se llama cada ~2 s por jugador dentro de la dimension. */
    public static void tick(ServerLevel level, ServerPlayer p) {
        if (TABLE.isEmpty()) load();
        int mon = 0, wc = 0, wa = 0;
        for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(96.0), e -> e instanceof SeaCreature || e instanceof LeviathanEntity)) {
            MobCategory c = m.getType().getCategory();
            if (c == MobCategory.MONSTER) mon++; else if (c == MobCategory.WATER_CREATURE) wc++; else if (c == MobCategory.WATER_AMBIENT) wa++;
        }
        RandomSource r = level.getRandom();
        boolean peaceful = level.getDifficulty() == Difficulty.PEACEFUL;
        for (int attempt = 0; attempt < 3; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2, dist = 24 + r.nextInt(48);
            int x = (int) (p.getX() + Math.cos(ang) * dist), z = (int) (p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z);
            if (floor > SEA - 8) continue;                                        // isla o aguas muy someras
            int y;
            if (r.nextFloat() < 0.6F) y = (int) p.getY() + r.nextInt(61) - 30;   // cerca de donde estas
            else y = floor + 1 + r.nextInt(Math.max(1, SEA - 3 - floor));        // cualquier profundidad
            y = Math.max(floor + 1, Math.min(SEA - 3, y));
            char band = y >= SEA - 22 ? 's' : (y <= floor + 25 ? 'b' : 'm');
            BlockPos pos = new BlockPos(x, y, z);
            Holder<Biome> biome = level.getBiome(pos);
            List<Entry> candidates = new ArrayList<>();
            int total = 0;
            for (Map.Entry<ResourceKey<Biome>, List<Entry>> be : TABLE.entrySet()) {
                if (!biome.is(be.getKey())) continue;
                for (Entry en : be.getValue()) {
                    if (en.bands.indexOf(band) < 0 && !(en.bottom && band == 'b')) continue;
                    if (en.cat == MobCategory.MONSTER && (peaceful || mon >= CAP_MONSTER)) continue;
                    if (en.cat == MobCategory.WATER_CREATURE && wc >= CAP_CREATURE) continue;
                    if (en.cat == MobCategory.WATER_AMBIENT && wa >= CAP_AMBIENT) continue;
                    candidates.add(en); total += en.weight;
                }
            }
            if (candidates.isEmpty() || total <= 0) continue;
            int roll = r.nextInt(total);
            Entry pick = candidates.get(0);
            for (Entry en : candidates) { roll -= en.weight; if (roll < 0) { pick = en; break; } }
            EntityType<?> type = ModRegistry.ENTITIES.get(pick.id);
            int n = Math.min(4, pick.min + r.nextInt(pick.max - pick.min + 1));
            for (int i = 0; i < n; i++) {
                double ex = x + 0.5 + (r.nextDouble() - 0.5) * 5, ez = z + 0.5 + (r.nextDouble() - 0.5) * 5;
                double ey = pick.bottom ? floor : y + (r.nextDouble() - 0.5) * 4;
                Entity e = type.create(level, EntitySpawnReason.NATURAL);
                if (e == null) continue;
                e.setPos(ex, ey, ez);
                if (!level.getFluidState(BlockPos.containing(ex, ey + 0.5, ez)).is(FluidTags.WATER) || !level.noCollision(e)) { e.discard(); continue; }
                level.addFreshEntity(e);
                if (pick.cat == MobCategory.MONSTER) mon++; else if (pick.cat == MobCategory.WATER_CREATURE) wc++; else wa++;
            }
        }
    }
}
