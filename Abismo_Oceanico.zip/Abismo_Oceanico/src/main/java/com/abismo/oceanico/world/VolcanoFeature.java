package com.abismo.oceanico.world;

import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import static com.abismo.oceanico.world.Gen.b;

/** Volcan submarino: cono de basalto con cráter de lava y chimeneas hidrotermales. */
public class VolcanoFeature extends Feature<NoneFeatureConfiguration> {
    public VolcanoFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        Gen g = new Gen(lv, ctx.random());
        int cx = ctx.origin().getX(), cz = ctx.origin().getZ(), y0 = ctx.origin().getY() - 4;
        int R = 12, H = 12 + g.r.nextInt(8);
        BlockState basalt = b("basalto_volcanico"), magma = Blocks.MAGMA_BLOCK.defaultBlockState(), lava = Blocks.LAVA.defaultBlockState();
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d > R) continue;
            int h = (int) Math.round(H * Math.pow(1 - d / R, 1.25)) + (g.r.nextInt(3) == 0 ? 1 : 0);
            boolean crater = d < 3.2;
            int top = crater ? Math.max(1, h - 4) : h;
            for (int y = -3; y <= top; y++) {
                BlockState s = (g.r.nextInt(9) == 0 && y > top - 2) ? magma : basalt;
                if (crater && y >= top - 1) s = lava;
                g.put(cx + x, y0 + y, cz + z, s);
            }
            if (crater) for (int y = top + 1; y <= H; y++) g.put(cx + x, y0 + y, cz + z, Gen.WATER);
        }
        for (int i = 0; i < 6; i++) {
            double a = g.r.nextDouble() * Math.PI * 2, d = 4 + g.r.nextInt(7);
            int vx = cx + (int) (Math.cos(a) * d), vz = cz + (int) (Math.sin(a) * d);
            int vy = y0 + (int) Math.round(H * Math.pow(1 - d / R, 1.25)) + 1;
            g.put(vx, vy, vz, b("chimenea_hidrotermal"));
        }
        return true;
    }
}
