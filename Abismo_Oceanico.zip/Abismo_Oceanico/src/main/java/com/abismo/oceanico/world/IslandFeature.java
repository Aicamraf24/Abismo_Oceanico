package com.abismo.oceanico.world;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Mini isla en la superficie del oceano, con una palmera y un tesoro enterrado marcado con una X de arena roja. */
public class IslandFeature extends Feature<NoneFeatureConfiguration> {
    /** nivel del mar de la dimension (noise_settings.sea_level) */
    public static final int SEA = 290;

    public IslandFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lv = ctx.level();
        RandomSource r = ctx.random();
        Gen g = new Gen(lv, r);
        int cx = ctx.origin().getX(), cz = ctx.origin().getZ();
        int top = SEA + 1;                                   // la superficie queda 1-2 bloques sobre el agua
        int R = 4 + r.nextInt(4);
        BlockState sand = Blocks.SAND.defaultBlockState(), grass = Blocks.GRASS_BLOCK.defaultBlockState();
        BlockState sandstone = Blocks.SANDSTONE.defaultBlockState(), stone = Blocks.STONE.defaultBlockState();
        for (int dx = -R - 1; dx <= R + 1; dx++) {
            for (int dz = -R - 1; dz <= R + 1; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz) + (r.nextDouble() - 0.5) * 1.2;
                if (dist > R) continue;
                int topY = dist > R * 0.7 ? top - 1 : top;
                int depth = (int) ((R - dist) * 1.4) + 3;
                for (int y = topY; y >= topY - depth; y--) {
                    BlockState s = y == topY ? (dist < R * 0.55 ? grass : sand) : (y >= topY - 2 ? sand : (y >= topY - 4 ? sandstone : stone));
                    g.put(cx + dx, y, cz + dz, s);
                }
                for (int y = topY + 1; y <= top + 7; y++) {            // despejar el aire sobre la isla
                    BlockPos p = new BlockPos(cx + dx, y, cz + dz);
                    if (lv.ensureCanWrite(p) && !lv.getBlockState(p).isAir() && y <= SEA) lv.setBlock(p, Gen.AIR, 2);
                }
            }
        }
        // palmera
        int h = 4 + r.nextInt(2);
        BlockState log = Blocks.JUNGLE_LOG.defaultBlockState();
        BlockState leaf = Blocks.JUNGLE_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        g.box(cx - 1, top + 1, cz - 1, cx - 1, top + h, cz - 1, log);
        for (int dx = -3; dx <= 1; dx++) for (int dz = -3; dz <= 1; dz++) {
            double d = Math.abs(dx + 1) + Math.abs(dz + 1);
            if (d <= 3 && d > 0) g.put(cx - 1 + (dx + 1), top + h, cz - 1 + (dz + 1), leaf);
        }
        g.put(cx - 1, top + h + 1, cz - 1, leaf);
        // tesoro enterrado bajo una X de arena roja
        int tx = cx + 2, tz = cz + 1;
        g.chest(tx, top - 3, tz, "isla");
        BlockState red = Blocks.RED_SAND.defaultBlockState();
        g.put(tx, top, tz, red);
        g.put(tx + 1, top, tz + 1, red); g.put(tx - 1, top, tz - 1, red);
        g.put(tx + 1, top, tz - 1, red); g.put(tx - 1, top, tz + 1, red);
        return true;
    }
}
