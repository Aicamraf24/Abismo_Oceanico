package com.abismo.oceanico;

import net.minecraft.resources.Identifier;

public final class Ids {
    public static final String MOD_ID = "abismo_oceanico";
    private Ids() {}

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }
}
