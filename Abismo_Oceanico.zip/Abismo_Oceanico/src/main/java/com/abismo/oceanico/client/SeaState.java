package com.abismo.oceanico.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class SeaState extends LivingEntityRenderState {
    /** progreso de la animacion de ataque (0..1) */
    public float attack;
}
