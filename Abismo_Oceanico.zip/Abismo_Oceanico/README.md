# Abismo Oceánico — mod Fabric para Minecraft Java 26.1.2

Dimensión submarina con ciudades hundidas, 25 criaturas con reproducción, jefe **Leviatán del Abismo**, minerales,
5 conjuntos de armadura, 6 armas, portal y sistema de presión/oxígeno/corrientes. **Sin sonidos ni archivos de audio.**

> ⚠️ **ESTADO HONESTO**: este proyecto **NO ha sido compilado ni probado dentro del juego**. El entorno donde se generó no tiene
> acceso a internet, así que no pudo descargar Minecraft 26.1.2, Loom ni Fabric API. Lo único verificado es: todos los JSON son válidos,
> todas las referencias (texturas, modelos, recetas, drops, biomas, especies) existen, y el código Java no tiene errores de sintaxis.
> Es muy probable que la primera compilación muestre algunos errores de nombres de API: se corrigen en pocos minutos (ver abajo).

## Cómo compilar (GitHub Actions, sin instalar nada)
1. Crea un repositorio en GitHub y sube **el contenido** de esta carpeta (no la carpeta contenedora).
2. Ve a *Actions* → workflow **build** → se ejecuta solo al subir (o *Run workflow*).
3. Descarga el artefacto `abismo_oceanico-jar` y copia el `.jar` (el que **no** termina en `-sources`) a tu carpeta `mods` de PineconeMC.
4. Si falla, copia el error del log y pásalo: se corrige.

Versiones usadas (tomadas del `fabric-example-mod` rama 26.1.2): Loader 0.19.3, Loom 1.17-SNAPSHOT, Fabric API 0.155.2+26.1.2,
Gradle 9.5.0, Java 25. No incluyo `gradle-wrapper.jar` (no pude descargarlo): el workflow usa `gradle/actions/setup-gradle`.
Para compilar en local ejecuta `gradle wrapper` una vez y luego `./gradlew build`.

## Puntos de API con más riesgo (si el compilador se queja, es aquí)
Todo está escrito para nombres oficiales de Mojang (26.1 sin ofuscar). Lo que no pude comprobar contra el código real:
- `Animal`/`Mob`: `doHurtTarget(ServerLevel, Entity)`, `hurtServer(...)`, `customServerAiStep(ServerLevel)`, `Animal.createAnimalAttributes()`, `getBreedOffspring`.
- `EntityType.create(level, EntitySpawnReason)`, `ServerPlayer.teleportTo(level,x,y,z,Set,yaw,pitch,boolean)`.
- Items: `Item.Properties.humanoidArmor/sword/food/attributes`, `TridentItem.createAttributes()`, `CrossbowItem::new`.
- Render: `MobRenderer`, `LivingEntityRenderState.walkAnimationSpeed/Pos/ageInTicks`, `EntityRenderers.register`, `ModelLayerRegistry.registerModelLayer`, `ChunkSectionLayerMap.putBlock`.
- Imports de `Animal`/`WaterAnimal` si Mojang los movió a subpaquetes.
- Datos: formato de `dimension_type`, `biome` (atributos visuales) y `noise_settings` (density functions) — lo más delicado. Si la dimensión no carga, el log indica el JSON exacto.

## Contenido
- **Dimensión** `abismo_oceanico:abismo`: 100 % submarina (nivel del mar en y=290: bajo el agua y, encima, aire para las islas), terreno por ruido propio, cuevas inundadas, trincheras, 8 biomas.
- **Biomas**: Arrecife Luminoso, Abismo Oscuro, Bosque de Algas Colosales, Cementerio de Barcos, Volcanes Submarinos, Jardín de Medusas, Trinchera del Leviatán, Océano Cristalino.
- **Estructuras** (generadas como *features* propias en Java): ciudades hundidas (palacio con salón real, torres, templos, bibliotecas, laboratorios, cárceles con guardianes, puentes, estatuas, cámara secreta bajo cristal con cofres y spawner), naufragios, volcanes submarinos con lava y chimeneas, y el **Santuario de las Profundidades** (solo en la Trinchera del Leviatán). Limitación: cada una cabe en unos 30×30 bloques.
- **25 criaturas + jefe**, cada una con anatomía 3D propia (18 plantillas distintas), textura propia, animaciones procedurales, estadísticas, IA y drops.
- **Reproducción** de todas las especies **excepto el Leviatán**: alimentar con el ítem de la tabla → modo amor → cría que crece. Límite local de población por especie para cuidar el rendimiento.
- **Jefe Leviatán del Abismo**: 700 PV, barra de jefe, 3 fases, golpes de tentáculos con aviso, ondas de presión, remolinos, invocaciones y mordida. Se invoca con el **Corazón del Abismo** sobre el **Altar Abisal** del Santuario.
- **Recursos**: Cristal Abisal, Perla Oscura, Mineral de Coral, Esencia Marina, Fragmento de Leviatán, Mineral de Presión, Cristal Bioluminiscente, Núcleo Oceánico (+ lingotes, menas y bloques).
- **Armaduras**: Coral, Perla Abisal, Escamas de Leviatán, Guardián Oceánico, Abismo. **Armas**: Espada de Coral, Daga de las Profundidades, Lanza del Leviatán, Tridente Abisal, Arpón Oceánico, Ballesta Submarina.
- **Huevos generadores**: uno por criatura (26), con textura propia del color de la criatura (cuerpo + manchas del color de acento).
- **Mini islas**: islas de arena y hierba en la superficie, con una palmera y un tesoro enterrado marcado con una X de arena roja (cofre con botín propio).
- **Interiores secos**: el interior de torres, palacios, bibliotecas, laboratorios, cárceles, la cámara secreta y el camarote del naufragio tiene aire; las entradas son puertas de madera (el agua no pasa por ellas). El Santuario del Leviatán sigue inundado, porque el jefe nada.
- **Bombona de Oxígeno** (reutilizable, 24 usos): rellena el aire y da respiración acuática 3 minutos. Receta: 3 cristal, 2 cuero y 2 hierro (columna central de cristal, hierro arriba, cuero a los lados).
- **Comida**: carnes crudas/cocinadas (marina, tiburón, cangrejo) y tentáculo asado; horno, ahumador y hoguera.

## Exploración y supervivencia
- **Presión** (solo en la dimensión): bajo y=140 necesitas 6 puntos de equipo, bajo y=90 → 12, bajo y=50 → 20. Cada pieza aporta puntos (Coral 2, Perla 3, Guardián 4, Escamas 5, Abismo 6). Sin ellos: lentitud, fatiga y daño suave. **Nunca te mata** (el daño se detiene con 3 corazones).
- **Armaduras**: respiración submarina (casco), gracia del delfín (pantalones/botas), visión submarina (cascos salvo Coral), resistencia (2+ piezas de Guardián/Escamas/Abismo).
- **Corrientes** que empujan suavemente. **Cápsula de Oxígeno**, **Antorcha Marina**, **Lámpara Marina**, plantas bioluminiscentes.

## Portal
Marco 4×5 (interior 2×3) de **Marco del Portal Abisal** (receta: ladrillo abisal, lingote de coral, cristal abisal) activado con la **Llave de la Marea**. Permanece 3 segundos dentro para viajar; se crea el portal de regreso; conservas inventario y progreso.

## Criaturas y reproducción
| Criatura | Categoría | Comportamiento | PV | Alimento de cría |
|---|---|---|---|---|
| Tiburón Abisal | monster | hostile | 38 | cod, salmon |
| Megalodón | monster | hostile | 140 | salmon |
| Anguila Eléctrica Gigante | monster | hostile | 44 | cod, salmon |
| Calamar Colosal | monster | territorial | 80 | cod, salmon |
| Pulpo de las Profundidades | water_creature | neutral | 40 | kelp |
| Serpiente Marina | monster | hostile | 40 | cod, salmon |
| Pez Abisal Dentado | monster | hostile | 14 | kelp |
| Cangrejo Gigante | water_creature | territorial | 44 | kelp, seagrass |
| Raya Fantasma | water_creature | neutral | 30 | cod |
| Leviatán Menor | monster | hostile | 170 | salmon |
| Medusa Luminosa | water_ambient | passive | 10 | glow_berries |
| Tortuga Colosal | water_creature | passive | 70 | seagrass |
| Caballito de Mar Gigante | water_creature | skittish | 20 | kelp |
| Pez Linterna | water_ambient | skittish | 6 | kelp |
| Mantarraya Abisal | water_creature | skittish | 45 | kelp |
| Nautilo Gigante | water_creature | neutral | 34 | glow_berries |
| Pez Globo Colosal | water_creature | neutral | 26 | kelp |
| Camarón Blindado | water_creature | neutral | 30 | kelp, seagrass |
| Dragón Marino | monster | hostile | 150 | salmon |
| Ballena Abisal | water_creature | passive | 220 | cod, kelp |
| Guardián Coralino | monster | hostile | 70 | prismarine_crystals |
| Gólem de Coral | monster | hostile | 130 | prismarine_shard |
| Depredador de las Trincheras | monster | hostile | 140 | salmon |
| Kraken Menor | monster | hostile | 210 | salmon |
| Anguila de Cristal | monster | hostile | 55 | amethyst_shard |
| Leviatán del Abismo | monster | boss | 700 | — (jefe, no se reproduce) |

## Compatibilidad
Id único `abismo_oceanico`. No modifica ni reemplaza contenido de otros mods ni de vanilla (solo añade valores a etiquetas de madera) y no depende de ningún otro mod: no hay integraciones activas con Acechador, Cápsulas, Gancho, Reptilia, End Realms, Mundo Prehistórico ni El Vacío Profundo, por lo que no hay conflictos de identificadores.

## Limitaciones conocidas
- Sin huevos generadores: usa `/summon abismo_oceanico:tiburon_abisal` (o el id de cada criatura).
- El Tridente y el Arpón lanzan el proyectil vanilla del tridente; la Ballesta no tiene animación de tensado.
- Las texturas se generaron proceduralmente (píxel art simple).
- Valores de equilibrio sin probar en juego.
